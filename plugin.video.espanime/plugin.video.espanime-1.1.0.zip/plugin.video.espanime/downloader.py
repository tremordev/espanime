# Autor: tremordev
# Descarga de episodios. Resuelve el embed con ResolveURL y descarga el
# stream resultante (mp4 directo o HLS/m3u8) con youtube-dl y, si falla o no
# está instalado, con yt-dlp como alternativa. Ambos traen descargador HLS
# nativo (segmentos + AES) sin necesitar ffmpeg.

import importlib
import os
import sys
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()


def _ensure_module_on_path(addon_id):
    """
    Añade la carpeta lib de un módulo a sys.path importándola directamente del
    disco. No se usa xbmcaddon.Addon() porque falla si el módulo está
    deshabilitado en Kodi; el código es Python puro y se importa igual desde
    sus ficheros. Devuelve True si la carpeta existe.
    """
    candidates = [f"special://home/addons/{addon_id}/lib"]
    try:
        here = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
        candidates.append(os.path.join(os.path.dirname(here), addon_id, "lib"))
    except Exception:
        pass

    for cand in candidates:
        lib = xbmcvfs.translatePath(cand)
        if os.path.isdir(lib):
            if lib not in sys.path:
                sys.path.insert(0, lib)
            return True
    return False


def _load_engine(module_name):
    """
    Importa la clase YoutubeDL de youtube_dl o yt_dlp. Devuelve None si el
    módulo no está (ImportError) o si falla al cargar por otra causa (módulo
    incompatible con la versión de Python, ficheros corruptos): en ese caso
    se loguea y se sigue con el otro motor en vez de tumbar la descarga.
    """
    try:
        return importlib.import_module(module_name).YoutubeDL
    except ImportError:
        return None
    except Exception as exc:
        xbmc.log(f"[Anime] {module_name} no se pudo cargar: {exc}", xbmc.LOGWARNING)
        return None

try:
    import resolveurl
    _HAS_RESOLVEURL = True
except ImportError:
    _HAS_RESOLVEURL = False


def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification("Descargas", msg, icon, ms)


def get_download_dir(ask_if_empty=True):
    """
    Devuelve la carpeta de descargas configurada. Si no hay y ask_if_empty,
    abre el diálogo para elegirla y la guarda.
    """
    path = ADDON.getSetting("download_path")
    if path:
        return path
    if not ask_if_empty:
        return ""
    chosen = xbmcgui.Dialog().browse(3, "Carpeta de descargas de anime", "files")
    if chosen:
        ADDON.setSetting("download_path", chosen)
    return chosen


def _safe_name(title):
    """Nombre de archivo seguro a partir del título del episodio."""
    name = re.sub(r"\[/?[A-Z]+[^\]]*\]", "", title)        # quita tags Kodi [B]/[COLOR]
    name = re.sub(r'[\\/:*?"<>|]', " ", name)               # caracteres prohibidos
    name = re.sub(r"\s+", " ", name).strip()
    return name or "anime"


def _resolve(video_url):
    """Resuelve el embed a URL directa. Devuelve (url, headers_dict)."""
    if not _HAS_RESOLVEURL:
        return None, {}
    try:
        hmf = resolveurl.HostedMediaFile(url=video_url)
        if not hmf:
            return None, {}
        resolved = hmf.resolve()
    except Exception as exc:
        xbmc.log(f"[Anime] download resolve: {exc}", xbmc.LOGWARNING)
        return None, {}
    if not resolved or not isinstance(resolved, str):
        return None, {}

    # ResolveURL puede anexar cabeceras: url|User-Agent=..&Referer=..
    headers = {}
    if "|" in resolved:
        resolved, header_str = resolved.split("|", 1)
        for pair in header_str.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                headers[k] = urllib.parse.unquote(v)
    return resolved, headers


def download(video_url, title):
    """Resuelve y descarga un episodio mostrando progreso en segundo plano."""
    _ensure_module_on_path("script.module.youtube.dl")
    _ensure_module_on_path("script.module.yt-dlp")
    # youtube-dl primero (motor actual); yt-dlp como alternativa si falta o falla.
    engines = [e for e in (_load_engine("youtube_dl"), _load_engine("yt_dlp")) if e is not None]
    if not engines:
        _notify("Falta youtube-dl o yt-dlp para descargar.", xbmcgui.NOTIFICATION_ERROR)
        return

    dest_dir = get_download_dir()
    if not dest_dir:
        _notify("Descarga cancelada: sin carpeta destino.", xbmcgui.NOTIFICATION_WARNING)
        return

    _notify("Resolviendo enlace…", ms=2000)
    direct_url, headers = _resolve(video_url)
    if not direct_url:
        _notify("No se pudo resolver el enlace para descargar.", xbmcgui.NOTIFICATION_ERROR)
        return

    # xbmcvfs.translatePath por si la ruta es special://
    dest_dir = xbmcvfs.translatePath(dest_dir)
    # El título llega como "Anime — Episodio N": una subcarpeta por anime mantiene
    # los episodios agrupados y ordenables por reproductores externos.
    if " — " in title:
        anime_part, ep_part = title.split(" — ", 1)
        dest_dir = os.path.join(dest_dir, _safe_name(anime_part))
        try:
            os.makedirs(dest_dir, exist_ok=True)
        except OSError as exc:
            xbmc.log(f"[Anime] download mkdir: {exc}", xbmc.LOGERROR)
            _notify("No se pudo crear la carpeta destino.", xbmcgui.NOTIFICATION_ERROR)
            return
        name = _safe_name(ep_part)
    else:
        name = _safe_name(title)
    outtmpl = os.path.join(dest_dir, name + ".%(ext)s")

    progress = xbmcgui.DialogProgressBG()
    progress.create("Descargando", name)

    def hook(d):
        if d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            done  = d.get("downloaded_bytes", 0)
            pct   = int(done * 100 / total) if total else 0
            speed = d.get("speed") or 0
            spd   = f"{speed / 1024 / 1024:.1f} MB/s" if speed else ""
            progress.update(pct, "Descargando", f"{name}  {spd}")
        elif d.get("status") == "finished":
            progress.update(100, "Procesando", name)

    opts = {
        "outtmpl": outtmpl,
        "format": "best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "nocheckcertificate": True,
        "hls_prefer_native": True,   # descargador HLS propio (sin ffmpeg)
        "hls_use_mpegts": True,      # .ts reproducible aunque se interrumpa
        "progress_hooks": [hook],
        "http_headers": headers or {},
    }

    ok = False
    try:
        for engine in engines:
            # dict(opts) por motor: yt-dlp guarda la referencia y puede mutarla.
            try:
                with engine(dict(opts)) as ydl:
                    ydl.download([direct_url])
                ok = True
                break
            except Exception as exc:
                xbmc.log(f"[Anime] download {engine.__module__}: {exc}", xbmc.LOGWARNING)
    finally:
        progress.close()

    if ok:
        _notify(f"Descargado: {name}", ms=5000)
    else:
        _notify(f"Falló la descarga de {name}.", xbmcgui.NOTIFICATION_ERROR, 5000)


def list_downloads():
    """Lista los archivos de vídeo descargados en la carpeta configurada."""
    dest_dir = get_download_dir(ask_if_empty=False)
    if not dest_dir:
        return []
    try:
        _, files = xbmcvfs.listdir(dest_dir)
    except Exception:
        return []
    exts = (".mp4", ".mkv", ".ts", ".avi", ".webm", ".m4v")
    out = []
    base = xbmcvfs.translatePath(dest_dir)
    for f in sorted(files):
        if f.lower().endswith(exts):
            out.append({"name": os.path.splitext(f)[0], "path": os.path.join(base, f)})
    return out
