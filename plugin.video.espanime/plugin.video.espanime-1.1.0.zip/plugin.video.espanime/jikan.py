# Autor: tremordev
# Cliente de Jikan (API REST pública de MyAnimeList, sin key) para estadísticas,
# reseñas, relacionados, recomendados y calendario de emisión.
# Cachea en disco con TTL por tipo; los fallos de red degradan a None/lista vacía.

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcvfs

_ENDPOINT  = "https://api.jikan.moe/v4"
_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espanime/jikan_cache/"
)
_TTL = {
    "statistics":      24 * 3600,
    "reviews":          6 * 3600,
    "recommendations": 12 * 3600,
    "relations":    7 * 24 * 3600,
    "schedule":        24 * 3600,
}


def _cache_path(key):
    return os.path.join(_CACHE_DIR, key.replace("/", "_") + ".json")


def _cache_get(key, ttl):
    path = _cache_path(key)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("_ts", 0) <= ttl:
            return obj.get("data")
    except (OSError, ValueError):
        pass
    return None


def _cache_set(key, data):
    os.makedirs(_CACHE_DIR, exist_ok=True)
    path = _cache_path(key)
    # tmp único por proceso + os.replace (mismo patrón que anilist): la lectura es
    # atómica aunque varias invocaciones de Kodi escriban a la vez, y el PID evita
    # que dos procesos pisen el mismo tmp. Se limpia el tmp si el write falla.
    tmp = f"{path}.{os.getpid()}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"_ts": time.time(), "data": data}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as exc:
        xbmc.log(f"[Anime] jikan cache write {key}: {exc}", xbmc.LOGWARNING)
        try:
            os.remove(tmp)
        except OSError:
            pass


def _get(path, params=None):
    url = _ENDPOINT + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; espanime-kodi/1.1)",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, OSError, ValueError) as exc:
        xbmc.log(f"[Anime] Jikan GET {path}: {exc}", xbmc.LOGWARNING)
        return None


def _cached_call(key, ttl, path, params=None):
    cached = _cache_get(key, ttl)
    if cached is not None:
        return cached
    data = _get(path, params)
    if data and "data" in data:
        _cache_set(key, data["data"])
        return data["data"]
    return None


def get_statistics(mal_id):
    return _cached_call(f"statistics_{mal_id}", _TTL["statistics"],
                        f"/anime/{mal_id}/statistics")


def get_reviews(mal_id, page=1):
    """Devuelve (items, pagination). Caché de ambos juntos por página."""
    key    = f"reviews_{mal_id}_p{page}"
    cached = _cache_get(key, _TTL["reviews"])
    if cached is not None:
        return cached.get("items", []), cached.get("pagination", {})
    data = _get(f"/anime/{mal_id}/reviews", {"page": page})
    if data and "data" in data:
        bundle = {"items": data["data"], "pagination": data.get("pagination", {})}
        _cache_set(key, bundle)
        return bundle["items"], bundle["pagination"]
    return [], {}


def get_recommendations(mal_id):
    return _cached_call(f"recommendations_{mal_id}", _TTL["recommendations"],
                        f"/anime/{mal_id}/recommendations") or []


def get_relations(mal_id):
    return _cached_call(f"relations_{mal_id}", _TTL["relations"],
                        f"/anime/{mal_id}/relations") or []


def get_schedule(day):
    """day en minúsculas (monday..sunday). Solo la primera página (~25 anime)."""
    return _cached_call(f"schedule_{day}", _TTL["schedule"],
                        "/schedules", {"filter": day, "limit": 25}) or []


def clear_cache():
    """Borra todos los .json de la caché de Jikan. Devuelve el número de archivos
    eliminados. Nunca lanza."""
    removed = 0
    try:
        if not os.path.isdir(_CACHE_DIR):
            return 0
        for fname in os.listdir(_CACHE_DIR):
            if fname.endswith(".json"):
                try:
                    os.remove(os.path.join(_CACHE_DIR, fname))
                    removed += 1
                except OSError:
                    pass
    except OSError as exc:
        xbmc.log(f"[Anime] jikan clear_cache falló: {exc}", xbmc.LOGWARNING)
    return removed
