# Autor: tremordev
# Servicio de fondo: auto-skip de openings/endings vía AniSkip durante la reproducción.
# El plugin deja {anime, episode} en una Window Property al reproducir; este daemon lo
# lee en onAVStarted, consulta AniSkip (con el idMal de AniList) y salta los intervalos.
# Vive mientras Kodi está abierto, en proceso aparte del plugin.

import base64
import json
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui

sys.path.insert(0, os.path.dirname(__file__))
import anilist
import ping

_ADDON    = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo("id")
_PROP     = "espanime.nowplaying"
_WIN      = xbmcgui.Window(10000)


def _aniskip_on():
    return _ADDON.getSetting("aniskip_enabled") != "false"


def _upnext_on():
    return _ADDON.getSetting("upnext_enabled") != "false"


def _send_upnext(info, nxt):
    """Notifica al servicio service.upnext (si está instalado) los datos del episodio
    actual y el siguiente. Up Next muestra el popup y, si se acepta, abre next play_url."""
    anime = info.get("anime", "")
    payload = {
        "current_episode": {
            "episodeid": f"{anime}:{info.get('episode', 0)}",
            "tvshowid":  anime,
            "title":     f"Episodio {info.get('episode', 0)}",
            "showtitle": anime,
            "season":    1,
            "episode":   info.get("episode", 0),
            "playcount": 0,
        },
        "next_episode": {
            "episodeid": f"{anime}:{nxt.get('num', 0)}",
            "tvshowid":  anime,
            "title":     f"Episodio {nxt.get('num', 0)}",
            "showtitle": anime,
            "season":    1,
            "episode":   nxt.get("num", 0),
            "playcount": 0,
            "art":       {},
        },
        "play_url": nxt.get("url", ""),
    }
    if not payload["play_url"]:
        return
    enc = base64.b64encode(json.dumps(payload).encode("utf-8")).decode("ascii")
    xbmc.executebuiltin(f"NotifyAll({_ADDON_ID}, upnext_data, {enc})")


class _Monitor(xbmc.Player):

    def __init__(self):
        super().__init__()
        self.skips = []
        self.done  = set()

    def onAVStarted(self):
        self.skips = []
        self.done  = set()
        raw = _WIN.getProperty(_PROP)
        _WIN.clearProperty(_PROP)          # se consume una sola vez
        if not raw:
            return
        try:
            info = json.loads(raw)
        except json.JSONDecodeError:
            return
        anime = info.get("anime", "")
        if not anime:
            return
        # Descarta una propiedad obsoleta (un play que resolvió pero no arrancó deja
        # la property sin consumir; sin esto, el siguiente vídeo CUALQUIERA en Kodi
        # heredaría sus marcas/Up Next). Ventana de 2 min entre el play y onAVStarted.
        if abs(time.time() - info.get("ts", 0)) > 120:
            return

        # Up Next: no requiere red (la URL del siguiente ya viene calculada).
        nxt = info.get("next")
        if nxt and _upnext_on():
            _send_upnext(info, nxt)

        # AniSkip: requiere idMal de AniList (cache-hit habitual).
        if not _aniskip_on():
            return
        rich = anilist.enrich(anime)
        mal  = rich.get("idMal", 0)
        if not mal:
            return
        try:
            length = int(self.getTotalTime())
        except Exception:
            length = 0
        self.skips = anilist.get_skip_times(mal, info.get("episode", 0), length)

    def check(self):
        if not self.skips or not self.isPlayingVideo():
            return
        try:
            pos = self.getTime()
        except Exception:
            return
        for sk in self.skips:
            key = sk.get("skipType", "")
            if key in self.done:
                continue
            if sk["start"] <= pos < sk["end"]:
                self.seekTime(sk["end"])
                self.done.add(key)
                label = "Opening" if key == "op" else "Ending"
                xbmc.executebuiltin(f"Notification(Anime, {label} omitido, 2000)")


if __name__ == "__main__":
    ping.ping()                        # telemetria anonima: 1 ping por sesion (throttle 24h)
    monitor = xbmc.Monitor()
    player  = _Monitor()
    while not monitor.abortRequested():
        player.check()
        if monitor.waitForAbort(1):
            break
