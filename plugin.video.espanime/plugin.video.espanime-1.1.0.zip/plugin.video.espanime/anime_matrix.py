# Autor: tremordev
# Fondo animado tipo "lluvia anime" para Espanime.
# Genera un XML de skin con etiquetas ASCII que caen y pulsan; sin threads de Python.
# Inspirado en ascii_matrix.py de TopZilla (RubénSDFA1laberot, GPL-2.0-or-later).

import os
import struct
import zlib
import random

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

_ADDON    = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo("id")
_ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo("path"))

_SKIN_BASE = os.path.join(_ADDON_PATH, "resources", "skins", "Default", "1080i")
_XML_NAME  = "espanime-rain.xml"
_XML_PATH  = os.path.join(_SKIN_BASE, _XML_NAME)
_MEDIA     = os.path.join(_ADDON_PATH, "resources", "media")
_WHITE_FS  = os.path.join(_MEDIA, "_white.png")
_TRANSP_FS = os.path.join(_MEDIA, "_transp.png")
_WHITE_URI  = f"special://home/addons/{_ADDON_ID}/resources/media/_white.png"
_FANART_URI = f"special://home/addons/{_ADDON_ID}/fanart.jpg"

# Patrones de lluvia/sakura/energía-ki (ASCII puro para máxima compat. de fuente)
_ROWS = [
    "  ~   .  ~  ~   .    ~  .   ~  ~  .  ~   .  ~  .   ~  ~  .   ~   .  ~  ~  .  ",
    " .  *   .    *  .   .    *  .   *   .  .    *   .    *  .   .  *   .    *   .  ",
    "  -   -   .  -  -  .   -   -  .   -   -  .  -   -   .  -   -  .  -   -   .  - ",
    "      *         .         *          .         *         .          *        .  ",
    "  . ~   . ~  .   ~ .  ~ .   . ~   ~ .  . ~  .   ~ .  ~ .   ~ .  . ~ .   ~ .   ",
    " *    .    *    .    *   .    *    .    *    .    *    .   *    .    *    .   *  ",
    "   -  ~  -   ~  -  ~   -  ~  -   ~   -  ~  -   ~  -  ~   -  ~  -   ~  -  ~  - ",
    " .   *  .  *   .  *  .   *  .   *  .   *  .  *   .  *  .   *   .  *  .   *  . ",
]

# Dos colores alternos: rosa-magenta y violeta. Ambos muy anime.
_COLORS = ("AAFF44CC", "AA9933FF")


def _write_atomic(path, data, binary=False):
    """Escribe a un tmp y hace os.replace (atómico en el mismo dir).

    Evita dos modos de fallo: (1) archivo truncado si Kodi muere a media escritura
    (quedaría corrupto y, al cachearse con 'if not exists', no se regeneraría nunca);
    (2) corrupción si dos invocaciones del plugin escriben el mismo archivo a la vez.
    El tmp lleva el PID para que invocaciones concurrentes no colisionen.
    """
    tmp = f"{path}.{os.getpid()}.tmp"
    if binary:
        with open(tmp, 'wb') as f:
            f.write(data)
    else:
        with open(tmp, 'w', encoding='utf-8') as f:
            f.write(data)
    os.replace(tmp, path)


def _make_png(color_type, raw_row):
    def _chunk(tag, data):
        body = tag + data
        return struct.pack('>I', len(data)) + body + struct.pack('>I', zlib.crc32(body) & 0xffffffff)
    ihdr = struct.pack('>I', 1) + struct.pack('>I', 1) + bytes([8, color_type, 0, 0, 0])
    return (
        b'\x89PNG\r\n\x1a\n'
        + _chunk(b'IHDR', ihdr)
        + _chunk(b'IDAT', zlib.compress(raw_row))
        + _chunk(b'IEND', b'')
    )


def _ensure_assets():
    if not os.path.exists(_WHITE_FS):
        _write_atomic(_WHITE_FS, _make_png(2, b'\x00\xff\xff\xff'), binary=True)       # RGB blanco
    if not os.path.exists(_TRANSP_FS):
        _write_atomic(_TRANSP_FS, _make_png(6, b'\x00\xff\xff\xff\x00'), binary=True)  # RGBA transparente


def _build_xml():
    rng = random.Random()
    lh  = 42
    labels = []
    y = 0
    for _ in range(2):
        for i in range(25):
            row = "    ".join(rng.choice(_ROWS) for _ in range(5))
            row = row.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            color = _COLORS[i % 2]
            labels.append(
                f'            <control type="label">\n'
                f'                <left>0</left>\n'
                f'                <top>{y}</top>\n'
                f'                <width>3000</width>\n'
                f'                <height>{lh}</height>\n'
                f'                <font>font12</font>\n'
                f'                <textcolor>{color}</textcolor>\n'
                f'                <label>{row}</label>\n'
                f'            </control>'
            )
            y += lh

    half_h   = 25 * lh
    lbl_xml  = "\n".join(labels)
    return f"""<?xml version="1.0" encoding="utf-8"?>
<window>
    <defaultcontrol>2</defaultcontrol>
    <controls>
        <control type="image">
            <left>0</left>
            <top>0</top>
            <width>1920</width>
            <height>1080</height>
            <texture>{_WHITE_URI}</texture>
            <colordiffuse>F2030810</colordiffuse>
        </control>

        <control type="group">
            <left>0</left>
            <top>-{half_h}</top>
            <width>1920</width>

            <!-- Pulso suave de opacidad -->
            <animation effect="fade" start="20" end="90" time="2500" pulse="true" condition="true">Conditional</animation>

            <!-- Caida vertical continua -->
            <animation effect="slide" start="0,0" end="0,{half_h}" time="35000" loop="true" condition="true">Conditional</animation>

{lbl_xml}
        </control>

        <control type="button" id="2">
            <left>0</left>
            <top>1200</top>
            <width>1</width>
            <height>1</height>
            <label> </label>
            <visible>false</visible>
        </control>
    </controls>
</window>
"""


class AnimeMatrixXML(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def onInit(self):
        pass

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.close()


def _ensure_xml():
    os.makedirs(_SKIN_BASE, exist_ok=True)
    _write_atomic(_XML_PATH, _build_xml())


def get_bg_dialog():
    _ensure_assets()
    _ensure_xml()
    return AnimeMatrixXML(_XML_NAME, _ADDON_PATH, "Default", "1080i")


def show():
    _ensure_assets()
    _ensure_xml()
    dlg = AnimeMatrixXML(_XML_NAME, _ADDON_PATH, "Default", "1080i")
    dlg.doModal()
    del dlg


# Fondo de iconos cayendo (para el gate legal)

_ICON_XML_NAME = "espanime-icons.xml"
_ICON_XML_PATH = os.path.join(_SKIN_BASE, _ICON_XML_NAME)

def _is_low_end():
    """True si el dispositivo tiene menos de 1.5 GB de RAM (Firestick 1ª gen, etc.).

    System.Memory(total) devuelve "<n>MB" (verificado en la fuente de Kodi: siempre MB,
    sin espacio ni decimales, en toda plataforma). Una lectura de 0 (prematura/fallida)
    o una excepción → se asume dispositivo capaz, para no degradar a un equipo potente.
    """
    try:
        raw = xbmc.getInfoLabel("System.Memory(total)")   # ej. "3954MB"
        mb = int("".join(c for c in raw if c.isdigit()))
        return 0 < mb < 1500
    except Exception:
        return False


def _build_icon_xml():
    # Detecta RAM en tiempo de generación (el XML se cachea, la detección ocurre una sola vez).
    # < 1.5 GB → modo ligero: 1 grupo vertical, 24 iconos.
    # ≥ 1.5 GB → modo completo: 3 grupos multidireccionales, ~92 iconos.
    low_end = _is_low_end()
    xbmc.log(f"[Anime] icon_bg: low_end={low_end}", xbmc.LOGINFO)

    rng = random.Random(77331)

    # Usa todos los PNGs del directorio media (excluye los auxiliares con prefijo _)
    available = sorted(
        f for f in os.listdir(_MEDIA)
        if f.endswith(".png") and not f.startswith("_")
    )
    if not available:
        return _build_xml()

    SZ = 64   # tamaño de icono en px (más grande = más visible, mismo fill rate)

    def icon_ctrl(lx, ly, name, alpha):
        uri = f"special://home/addons/{_ADDON_ID}/resources/media/{name}"
        return (
            f'            <control type="image">'
            f'<left>{lx}</left><top>{ly}</top>'
            f'<width>{SZ}</width><height>{SZ}</height>'
            f'<texture colordiffuse="{alpha}FFFFFF">{uri}</texture>'
            f'</control>'
        )

    alphas = ["38", "45", "40", "32"]

    # Grupo 1: cae hacia ABAJO
    # 3 columnas × 4 filas × 2 pasadas = 24 iconos
    # Contenido: 1920×2160px. half_h=1080. Grupo empieza top=-1080.
    COL1, ROW1 = 3, 4
    cw1, rh1 = 1920 // COL1, 1080 // ROW1   # 480, 270
    half_h = ROW1 * rh1                      # = 1080
    down = []
    y = 0
    for _ in range(2):
        for row in range(ROW1):
            for col in range(COL1):
                lx = col * cw1 + rng.randint(-50, 50)
                ly = y + rng.randint(-20, 20)
                down.append(icon_ctrl(lx, ly, rng.choice(available), rng.choice(alphas)))
            y += rh1

    # Grupo 2: se desplaza hacia la DERECHA
    # 3 filas × 4 columnas × 2 pasadas = 24 iconos
    # Contenido: 3840×1080px. half_w=1920. Grupo empieza left=-1920.
    COL2, ROW2 = 4, 3
    cw2, rh2 = 1920 // COL2, 1080 // ROW2   # 384, 360
    half_w = COL2 * cw2                      # = 1920
    right = []
    x = 0
    for _ in range(2):
        for col in range(COL2):
            for row in range(ROW2):
                lx = x + rng.randint(-30, 30)
                ly = row * rh2 + rng.randint(-30, 30)
                right.append(icon_ctrl(lx, ly, rng.choice(available), rng.choice(alphas)))
            x += cw2

    # Grupo 3: se desplaza hacia la IZQUIERDA
    # Misma cuadrícula que grupo 2, slide en dirección opuesta.
    # Grupo empieza left=0, desliza -1920.
    left_g = []
    x = 0
    for _ in range(2):
        for col in range(COL2):
            for row in range(ROW2):
                lx = x + rng.randint(-30, 30)
                ly = row * rh2 + rng.randint(-30, 30)
                left_g.append(icon_ctrl(lx, ly, rng.choice(available), rng.choice(alphas)))
            x += cw2

    down_xml = "\n".join(down)

    if low_end:
        # Firestick viejo u otro dispositivo < 1.5 GB: solo caída vertical (32 iconos, 1 grupo)
        extra_groups = ""
    else:
        right_xml = "\n".join(right)
        left_xml  = "\n".join(left_g)
        extra_groups = f"""
        <!-- Grupo 2: va hacia la derecha -->
        <control type="group">
            <left>-{half_w}</left><top>0</top><width>3840</width><height>1080</height>
            <animation effect="slide" start="0,0" end="{half_w},0" time="56000" loop="true" condition="true">Conditional</animation>
{right_xml}
        </control>

        <!-- Grupo 3: va hacia la izquierda -->
        <control type="group">
            <left>0</left><top>0</top><width>3840</width><height>1080</height>
            <animation effect="slide" start="0,0" end="-{half_w},0" time="72000" loop="true" condition="true">Conditional</animation>
{left_xml}
        </control>"""

    return f"""<?xml version="1.0" encoding="utf-8"?>
<window>
    <defaultcontrol>2</defaultcontrol>
    <controls>
        <!-- Fanart del addon como fondo -->
        <control type="image">
            <left>0</left><top>0</top><width>1920</width><height>1080</height>
            <texture>{_FANART_URI}</texture>
        </control>
        <!-- Velo oscuro sobre el fanart para que los iconos y el panel destaquen -->
        <control type="image">
            <left>0</left><top>0</top><width>1920</width><height>1080</height>
            <texture colordiffuse="BB000000">{_WHITE_URI}</texture>
        </control>

        <!-- Grupo 1: cae hacia abajo -->
        <control type="group">
            <left>0</left><top>-{half_h}</top><width>1920</width>
            <animation effect="slide" start="0,0" end="0,{half_h}" time="64000" loop="true" condition="true">Conditional</animation>
{down_xml}
        </control>
{extra_groups}
        <control type="button" id="2">
            <left>0</left><top>1200</top><width>1</width><height>1</height>
            <label> </label><visible>false</visible>
        </control>
    </controls>
</window>
"""


def _ensure_icon_xml():
    os.makedirs(_SKIN_BASE, exist_ok=True)
    # Cachea en disco: seed fijo → mismo resultado siempre, no hay que regenerar
    if not os.path.exists(_ICON_XML_PATH):
        _write_atomic(_ICON_XML_PATH, _build_icon_xml())


def get_icon_bg_dialog():
    """Fondo con iconos del addon cayendo, usado en el gate de aviso legal."""
    _ensure_assets()
    _ensure_icon_xml()
    return AnimeMatrixXML(_ICON_XML_NAME, _ADDON_PATH, "Default", "1080i")
