# Autor: tremordev
# Punto de entrada del addon. Enruta la URL de acción al módulo de menús.

import sys
import os

# Añadir el directorio del addon al path para imports relativos
sys.path.insert(0, os.path.dirname(__file__))

from espanime_menu import build_menu

build_menu()

