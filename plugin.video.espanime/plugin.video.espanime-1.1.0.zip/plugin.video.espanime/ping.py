"""Telemetria anonima: contador global de instalaciones.

Envia un unico ping por instalacion a Supabase sin transmitir ningun
identificador. El servidor acumula un total global; los registros con
mas de 30 dias se eliminan automaticamente via politica de retencion.
La dedup vive en el cliente (stats.json), que nunca se transmite.
"""
import base64
import json
import os
import threading
import time

import xbmcaddon
import xbmcvfs

_API_URL = "https://fnrlsaflbeyeqsaoebcr.supabase.co"
_API_KEY = base64.b64decode("ZXlKaGJHY2lPaUpJVXpJMU5pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SnBjM01pT2lKemRYQmhZbUZ6WlNJc0luSmxaaUk2SW1adWNteHpZV1pzWW1WNVpYRnpZVzlsWW1OeUlpd2ljbTlzWlNJNkltRnViMjRpTENKcFlYUWlPakUzT0RBMk5EazFOamNzSW1WNGNDSTZNakE1TmpJeU5UVTJOMzAucVJ0azR5STUzNFVsMDN4OXdRR3J0Q0w1QUpqYXFyUm9xNEd3dXNMbkJVTQ==").decode()
_TABLE = "pings"
_PING_INTERVAL_HOURS = 24
_DATA_FILE = 'stats.json'


def _data_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, _DATA_FILE)


def _load_data():
    path = _data_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    # JSON valido pero no-objeto (lista, null, numero) rompe data.get(): normaliza.
    return data if isinstance(data, dict) else {}


def _save_data(data):
    # Escritura atomica: un corte (cierre de Kodi) a media escritura dejaria el
    # JSON truncado, y al releerlo como corrupto se reenviaria el install. tmp con
    # PID (mismo patron que anilist/jikan) + os.replace garantiza que stats.json
    # siempre contenga un documento completo, sin colisionar con otro escritor.
    path = _data_path()
    tmp = f'{path}.{os.getpid()}.tmp'
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        # No critico: si no se guarda, el proximo arranque reenvia el ping.
        try:
            os.remove(tmp)
        except OSError:
            pass


def _send_ping(kind):
    """POST un ping anonimo a Supabase. True si el servidor lo acepto."""
    import requests

    headers = {
        'apikey': _API_KEY,
        'Authorization': f'Bearer {_API_KEY}',
        'Content-Type': 'application/json',
        # La tabla no tiene policy de SELECT: pedir la fila insertada de
        # vuelta fallaria con RLS. return=minimal evita ese reread.
        'Prefer': 'return=minimal',
    }
    payload = {
        'addon': xbmcaddon.Addon().getAddonInfo('id'),
        'kind': kind,
    }
    resp = requests.post(
        f'{_API_URL}/rest/v1/{_TABLE}',
        headers=headers,
        json=payload,
        timeout=10,
    )
    return resp.status_code in (200, 201, 204)


def _do_pings():
    try:
        data = _load_data()

        # Se guarda tras cada ping con exito: si el siguiente falla, lo ya
        # enviado queda registrado y no se reenvia (evita sobrecuenta).
        if not data.get('install_sent') and _send_ping('install'):
            data['install_sent'] = True
            _save_data(data)

        hours_since = (time.time() - data.get('last_ping', 0)) / 3600
        if hours_since >= _PING_INTERVAL_HOURS and _send_ping('daily'):
            data['last_ping'] = time.time()
            _save_data(data)
    except Exception:
        # Telemetria silenciosa en thread daemon: ningun fallo (red, addon,
        # disco) debe propagarse ni afectar a la sesion. Se reintenta al
        # proximo arranque porque stats.json no se actualizo.
        pass


def ping():
    """Lanza en segundo plano los pings pendientes. No bloquea ni propaga al llamador."""
    try:
        threading.Thread(target=_do_pings, daemon=True).start()
    except Exception:
        # La telemetria jamas debe impedir el arranque del servicio que la llama
        # (p.ej. el SO no puede crear el thread). Falla en silencio.
        pass
