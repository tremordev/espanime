# Autor: tremordev
# Enriquecimiento de metadatos vía AniList (GraphQL, sin API key).
# Aporta fanart (bannerImage), poster HD, sinopsis, puntuación y géneros.
# Cachea en disco 7 días; las respuestas con fallo NO se cachean (ver enrich).

import gzip
import hashlib
import json
import os
import re
import time
import urllib.request
import xbmc
import xbmcvfs
import xbmcaddon

_ADDON    = xbmcaddon.Addon()
_CACHE_DIR = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.espanime/anilist_cache/")
_TTL       = 7 * 86400  # 7 días en segundos
_ENDPOINT  = "https://graphql.anilist.co"

# Tras un 429, no se vuelve a consultar a AniList hasta este instante (evita
# martillear el endpoint al enriquecer muchos ítems). Estado de un solo hilo.
_backoff_until = 0.0

_MEDIA_FIELDS = """
    id
    idMal
    title { romaji english }
    description(asHtml: false)
    coverImage { extraLarge }
    bannerImage
    averageScore
    genres
    episodes
    status
    startDate { year }
    studios { nodes { name } }
"""

_QUERY = """
query ($search: String) {
  Media(search: $search, type: ANIME, isAdult: false) {
    %s
  }
}
""" % _MEDIA_FIELDS


def _cache_path(key):
    h = hashlib.md5(key.lower().encode()).hexdigest()
    return os.path.join(_CACHE_DIR, f"{h}.json")


def _cache_get(key):
    path = _cache_path(key)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if time.time() - data.get("_ts", 0) < _TTL:
            return data
    except Exception:
        pass
    return None


def _cache_set(key, data):
    os.makedirs(_CACHE_DIR, exist_ok=True)
    data["_ts"] = time.time()
    path = _cache_path(key)
    # Escritura atómica (tmp único por proceso + os.replace): con enrich_many
    # escribiendo muchos ficheros y varias invocaciones de Kodi a la vez, un lector
    # nunca debe ver un JSON a medias. tmp con PID evita colisión entre procesos.
    tmp = f"{path}.{os.getpid()}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as exc:
        xbmc.log(f"[AniList] cache write: {exc}", xbmc.LOGWARNING)
        try:
            os.remove(tmp)
        except OSError:
            pass


def get_cached(title):
    """
    Devuelve datos de AniList solo si ya están en caché. No hace llamadas de red.
    Útil para enriquecer listas sin esperar (latest_episodes, catálogo…).
    Devuelve {} si no está cacheado.
    """
    if not title:
        return {}
    data = _cache_get(title)
    if data is None:
        return {}
    data = dict(data)
    data.pop("_ts", None)
    return data


def _strip_html(text):
    """Quita tags HTML y entidades básicas de la descripción."""
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&quot;", '"').replace("&#039;", "'").replace("&nbsp;", " ")
    return text.strip()


def _extract_media(media):
    """Normaliza un objeto Media de AniList al dict que consume el addon."""
    return {
        "fanart":    media.get("bannerImage") or "",
        "poster":    (media.get("coverImage") or {}).get("extraLarge") or "",
        "plot_en":   _strip_html(media.get("description", "")),
        "score":     media.get("averageScore") or 0,
        "genres":    media.get("genres") or [],
        "episodes":  media.get("episodes") or 0,
        "status":    media.get("status") or "",
        "year":      (media.get("startDate") or {}).get("year") or 0,
        "studio":    ((media.get("studios") or {}).get("nodes") or [{}])[0].get("name") or "",
        "idMal":     media.get("idMal") or 0,
    }


def _query_anilist(title):
    """
    Consulta AniList. Devuelve (datos, ok).
      ok=True  → respuesta válida (con datos, o sin match → dict vacío): se puede cachear.
      ok=False → fallo de red/timeout/429/parseo: NO cachear, reintentar luego.
    """
    global _backoff_until
    if time.time() < _backoff_until:
        return {}, False  # en backoff por 429 reciente

    payload = json.dumps({"query": _QUERY, "variables": {"search": title}}).encode()
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (Anime Kodi Addon)",
    }
    req = urllib.request.Request(_ENDPOINT, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=6) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            body = json.loads(raw)
        media = body.get("data", {}).get("Media")
        if not media:
            return {}, True  # sin coincidencia: cachear vacío para no repreguntar
        return _extract_media(media), True
    except urllib.error.HTTPError as exc:
        if exc.code == 429:
            try:
                retry = int(exc.headers.get("Retry-After", "60"))
            except (TypeError, ValueError):
                retry = 60
            _backoff_until = time.time() + max(retry, 30)
            xbmc.log(f"[AniList] 429, backoff {retry}s", xbmc.LOGWARNING)
        else:
            xbmc.log(f"[AniList] HTTP {exc.code} para '{title}'", xbmc.LOGWARNING)
        return {}, False
    except (OSError, json.JSONDecodeError) as exc:
        xbmc.log(f"[AniList] query error '{title}': {exc}", xbmc.LOGWARNING)
        return {}, False


def enrich(title, existing_plot="", existing_poster=""):
    """
    Metadatos enriquecidos del anime. Mantiene plot/poster del scraper si existen.
    Solo se cachea (7 días) una respuesta válida; un fallo de red/429 NO se cachea
    (se reintenta). Nunca lanza: ante cualquier error devuelve lo que haya.

    Devuelve: {fanart, poster, plot, score, genres, episodes, status, ...}
    """
    if not title:
        return {"poster": existing_poster, "plot": existing_plot}
    try:
        cached = _cache_get(title)
        if cached is not None:
            result = dict(cached)
            result.pop("_ts", None)
        else:
            result, ok = _query_anilist(title)
            if ok:
                _cache_set(title, dict(result))  # cachea incluso vacío (no-match)
        # Prioriza datos locales (el scraper, en español) sobre AniList (inglés)
        result["poster"] = existing_poster or result.get("poster", "")
        result["plot"]   = existing_plot   or result.get("plot_en", "")
        return result
    except Exception as exc:
        xbmc.log(f"[AniList] enrich falló '{title}': {exc}", xbmc.LOGWARNING)
        return {"poster": existing_poster, "plot": existing_plot}


_BATCH_SIZE = 12  # alias por petición; AniList limita la complejidad de la query


def _query_batch(titles):
    """Consulta varios títulos en UNA petición vía aliases GraphQL.
    Devuelve (dict título->datos, ok). ok=False ante fallo de red/429 (no cachear).
    Los títulos sin coincidencia salen como {} (se cachean igual)."""
    global _backoff_until
    if not titles:
        return {}, True
    if time.time() < _backoff_until:
        return {}, False

    # Un alias mN por título, cada uno con su variable $sN. Se usa Page{media(...)}
    # (no Media(...)): Media lanza "Not Found" ante un título sin coincidencia y
    # AniList anula TODO el lote con 404; Page devuelve lista vacía sin romper el resto.
    var_defs = ", ".join(f"$s{i}: String" for i in range(len(titles)))
    aliases = "\n".join(
        f'm{i}: Page(perPage: 1) {{ media(search: $s{i}, type: ANIME, isAdult: false) {{ {_MEDIA_FIELDS} }} }}'
        for i in range(len(titles))
    )
    query = f"query ({var_defs}) {{\n{aliases}\n}}"
    variables = {f"s{i}": t for i, t in enumerate(titles)}
    payload = json.dumps({"query": query, "variables": variables}).encode()
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (Anime Kodi Addon)",
    }
    req = urllib.request.Request(_ENDPOINT, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                raw = gzip.decompress(raw)
            body = json.loads(raw)
        data = body.get("data")
        if not data:
            # Sin bloque data (error global de complejidad/rate-limit como 200+errors):
            # NO cachear nada, reintentar luego.
            if body.get("errors"):
                xbmc.log(f"[AniList] batch errors: {body['errors']}", xbmc.LOGWARNING)
            return {}, False
        result = {}
        for i, title in enumerate(titles):
            page = data.get(f"m{i}")
            if page is None:
                # Alias concreto anulado por un error: omitir (se reintenta), no cachear vacío.
                continue
            medias = page.get("media") or []
            result[title] = _extract_media(medias[0]) if (medias and medias[0]) else {}
        return result, True
    except urllib.error.HTTPError as exc:
        if exc.code == 429:
            try:
                retry = int(exc.headers.get("Retry-After", "60"))
            except (TypeError, ValueError):
                retry = 60
            _backoff_until = time.time() + max(retry, 30)
            xbmc.log(f"[AniList] 429 (batch), backoff {retry}s", xbmc.LOGWARNING)
        else:
            xbmc.log(f"[AniList] HTTP {exc.code} en batch", xbmc.LOGWARNING)
        return {}, False
    except (OSError, json.JSONDecodeError) as exc:
        xbmc.log(f"[AniList] batch error: {exc}", xbmc.LOGWARNING)
        return {}, False


def enrich_many(titles):
    """Precalienta la caché para una lista de títulos en pocas peticiones (aliases
    GraphQL), en vez de una llamada por título. Solo consulta los que no están en
    caché. No devuelve nada: tras llamarla, get_cached(title) tiene los datos.
    Nunca lanza."""
    try:
        pending, seen = [], set()
        for t in titles:
            if not t or t in seen:
                continue
            seen.add(t)
            if _cache_get(t) is None:
                pending.append(t)
        for start in range(0, len(pending), _BATCH_SIZE):
            chunk = pending[start:start + _BATCH_SIZE]
            data, ok = _query_batch(chunk)
            if not ok:
                break  # red caída o backoff: no insistir con el resto
            for title, media in data.items():
                _cache_set(title, dict(media))  # cachea incluso no-match (vacío)
    except Exception as exc:
        xbmc.log(f"[AniList] enrich_many falló: {exc}", xbmc.LOGWARNING)


def clear_cache():
    """Borra todos los .json de la caché de AniList. Devuelve el número de archivos
    eliminados. Nunca lanza."""
    removed = 0
    try:
        if not os.path.isdir(_CACHE_DIR):
            return 0
        for fname in os.listdir(_CACHE_DIR):
            if fname.endswith(".json"):
                try:
                    os.remove(os.path.join(_CACHE_DIR, fname))
                    removed += 1
                except OSError:
                    pass
    except OSError as exc:
        xbmc.log(f"[AniList] clear_cache falló: {exc}", xbmc.LOGWARNING)
    return removed


_PURGE_MARKER = os.path.join(_CACHE_DIR, ".last_purge")


def purge_expired():
    """Borra los .json caducados (>_TTL). Throttle a una pasada/día vía marcador.
    Usa mtime (el fichero se escribe al fijar _ts) para no abrir cada archivo;
    para un caché aproximar por mtime es suficiente. Nunca lanza."""
    try:
        if not os.path.isdir(_CACHE_DIR):
            return 0
        now = time.time()
        try:
            if now - os.path.getmtime(_PURGE_MARKER) < 86400:
                return 0
        except OSError:
            pass  # marcador ausente: primera purga
        removed = 0
        for fname in os.listdir(_CACHE_DIR):
            if not fname.endswith(".json"):
                continue
            path = os.path.join(_CACHE_DIR, fname)
            try:
                if now - os.path.getmtime(path) >= _TTL:
                    os.remove(path)
                    removed += 1
            except OSError:
                pass
        with open(_PURGE_MARKER, "w") as f:
            f.write(str(int(now)))
        return removed
    except OSError as exc:
        xbmc.log(f"[AniList] purge_expired falló: {exc}", xbmc.LOGWARNING)
        return 0


_ANISKIP = "https://api.aniskip.com/v2/skip-times"


def get_skip_times(mal_id, episode_number, episode_length=0):
    """
    Marcas de opening/ending desde AniSkip (api pública, sin auth). Requiere el id
    de MyAnimeList (idMal de AniList). Devuelve lista de
    {"skipType": "op"|"ed", "start": float, "end": float} o [] si no hay datos.
    Nunca lanza.
    """
    try:
        mal_id = int(mal_id)
    except (TypeError, ValueError):
        return []
    if mal_id <= 0:
        return []
    url = (f"{_ANISKIP}/{mal_id}/{int(episode_number)}"
           f"?types[]=op&types[]=ed&episodeLength={int(episode_length)}")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Anime Kodi Addon)"})
    try:
        with urllib.request.urlopen(req, timeout=6) as r:
            body = json.loads(r.read())
    except (OSError, json.JSONDecodeError) as exc:
        xbmc.log(f"[AniSkip] {mal_id}/{episode_number}: {exc}", xbmc.LOGDEBUG)
        return []
    if not body.get("found"):
        return []
    out = []
    for res in body.get("results", []):
        iv = res.get("interval") or {}
        start, end = iv.get("startTime"), iv.get("endTime")
        if start is None or end is None:
            continue
        out.append({"skipType": res.get("skipType", ""),
                    "start": float(start), "end": float(end)})
    return out
