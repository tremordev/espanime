# Autor: tremordev
# Ventana de aviso legal animada para el gate de primer arranque.
# WindowXMLDialog con texto autoscroll.
# Usa anime_matrix.py para el fondo de lluvia.

import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

_ADDON      = xbmcaddon.Addon()
_ADDON_ID   = _ADDON.getAddonInfo("id")
_ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo("path"))
_SKIN_BASE  = os.path.join(_ADDON_PATH, "resources", "skins", "Default", "1080i")
_XML_NAME   = "espanime-legal.xml"
_XML_PATH   = os.path.join(_SKIN_BASE, _XML_NAME)
_WHITE_URI  = f"special://home/addons/{_ADDON_ID}/resources/media/_white.png"


def _ensure_assets():
    import anime_matrix
    anime_matrix._ensure_assets()


def _build_xml():
    # Dimensiones del panel (1920×1080):
    #   Panel: left=500, top=350, width=920, height=380
    #   Textbox: left=515, top=392, width=890
    #   Botón OK: top=688, height=36
    # Botón único sustituido por RECHAZAR+ACEPTAR.
    PX, PY, PW = 500, 268, 920
    # Panel extendido hacia arriba para la sección de bienvenida (fondo igual: bottom=734).
    PH = 466

    corner = 16   # adornos de esquina (L-brackets HUD)

    def img(x, y, w, h, color):
        return (
            f'        <control type="image">\n'
            f'            <left>{x}</left><top>{y}</top>\n'
            f'            <width>{w}</width><height>{h}</height>\n'
            f'            <texture colordiffuse="{color}">{_WHITE_URI}</texture>\n'
            f'        </control>'
        )

    def lbl(x, y, w, h, text, font="font13", color="FFFFFFFF", align="center"):
        return (
            f'        <control type="label">\n'
            f'            <left>{x}</left><top>{y}</top>\n'
            f'            <width>{w}</width><height>{h}</height>\n'
            f'            <font>{font}</font>\n'
            f'            <textcolor>{color}</textcolor>\n'
            f'            <align>{align}</align>\n'
            f'            <label>{text}</label>\n'
            f'        </control>'
        )

    def btn(bid, x, y, w, h, label, tc, fc, nf_color, f_color, nav_left="", nav_right=""):
        nav = ""
        if nav_left:
            nav += f'            <onleft>{nav_left}</onleft>\n'
        if nav_right:
            nav += f'            <onright>{nav_right}</onright>\n'
        return (
            f'        <control type="button" id="{bid}">\n'
            f'            <left>{x}</left><top>{y}</top>\n'
            f'            <width>{w}</width><height>{h}</height>\n'
            f'            <font>font13</font>\n'
            f'            <label>{label}</label>\n'
            f'            <align>center</align>\n'
            f'            <textcolor>{tc}</textcolor>\n'
            f'            <focusedcolor>{fc}</focusedcolor>\n'
            f'            <texturenofocus colordiffuse="{nf_color}">{_WHITE_URI}</texturenofocus>\n'
            f'            <texturefocus   colordiffuse="{f_color}">{_WHITE_URI}</texturefocus>\n'
            f'{nav}'
            f'            <onup>{bid}</onup><ondown>{bid}</ondown>\n'
            f'        </control>'
        )

    # Layout vertical:
    #   Barra título: PY=350, h=40 → bottom=390
    #   Textbox:      top=392, h=282 → bottom=674
    #   Separador:    top=676, h=2
    #   Botones:      top=680, h=36 → bottom=716
    #   Panel bottom: PY+PH = 734 (16px margen)
    tb_top = 354   # subido 38px al quitar la franja azul
    tb_h   = 320
    sep_y  = 676
    btn_y  = 687
    btn_h  = 36
    # Dos botones centrados en los 920px del panel
    btn_w  = 380
    gap    = 30
    total  = btn_w * 2 + gap
    rej_x  = PX + (PW - total) // 2          # = 565
    acc_x  = rej_x + btn_w + gap             # = 975

    # Sección de bienvenida: PY=268 a y=348 (80px)
    # Barra de título (AVISO LEGAL): y=350
    WELCOME_H = 350 - PY   # = 82px

    controls = "\n".join([
        # Velo tenue; el fanart se ve detrás
        img(0, 0, 1920, 1080, "55000000"),

        # Panel principal
        img(PX, PY, PW, PH, "F0111827"),

        # Zona de bienvenida (fondo ligeramente diferente para distinguirla)
        img(PX, PY, PW, WELCOME_H, "FF0A1A3A"),

        # Bordes anime: magenta arriba/abajo, violeta lados
        img(PX,          PY,          PW, 3,  "FFFF44CC"),
        img(PX,          PY + PH - 3, PW, 3,  "FFFF44CC"),
        img(PX,          PY,          3,  PH, "FF8844FF"),
        img(PX + PW - 3, PY,          3,  PH, "FF8844FF"),

        # Adornos de esquina (L-brackets HUD)
        img(PX,                PY,            corner, 3, "FFFFFFFF"),
        img(PX,                PY,            3, corner, "FFFFFFFF"),
        img(PX + PW - corner,  PY,            corner, 3, "FFFFFFFF"),
        img(PX + PW - 3,       PY,            3, corner, "FFFFFFFF"),
        img(PX,                PY + PH - 3,   corner, 3, "FFFFFFFF"),
        img(PX,                PY + PH - corner, 3, corner, "FFFFFFFF"),
        img(PX + PW - corner,  PY + PH - 3,   corner, 3, "FFFFFFFF"),
        img(PX + PW - 3,       PY + PH - corner, 3, corner, "FFFFFFFF"),

        # Bienvenida: dos líneas cortas (Kodi trunca labels largas con "...")
        lbl(PX + 15, PY + 10, PW - 30, 26,
            "[B]Espanime te da la bienvenida[/B]",
            font="font13", color="FFFFD700"),
        lbl(PX + 15, PY + 40, PW - 30, 26,
            "Lee el aviso antes de continuar. Revisa tambien los Ajustes.",
            font="font13", color="FFCCCCDD"),

        # Separador bajo bienvenida
        img(PX + 30, 348, PW - 60, 2, "40FFFFFF"),

        # Textbox (id=1): font13, texto suave
        f'        <control type="textbox" id="1">\n'
        f'            <left>515</left><top>{tb_top}</top>\n'
        f'            <width>890</width><height>{tb_h}</height>\n'
        f'            <font>font13</font>\n'
        f'            <textcolor>FFE0E0FF</textcolor>\n'
        f'            <scrolltime>400</scrolltime>\n'
        f'            <ondown>21</ondown>\n'
        f'        </control>',

        # Separador
        img(PX, sep_y, PW, 2, "FF1a3a6c"),

        # Botón RECHAZAR (id=20)
        btn(20, rej_x, btn_y, btn_w, btn_h,
            "[B]RECHAZAR[/B]",
            tc="FFB0B0B0", fc="FFFF6644",
            nf_color="FF1a3a6c", f_color="CC3A0808",
            nav_right="21"),

        # Botón ACEPTAR (id=21): foco por defecto
        btn(21, acc_x, btn_y, btn_w, btn_h,
            "[B]ACEPTAR[/B]",
            tc="FF88CC88", fc="FFFFD700",
            nf_color="FF1a3a6c", f_color="CC003820",
            nav_left="20"),
    ])

    return f"""<?xml version="1.0" encoding="utf-8"?>
<window type="dialog">
    <defaultcontrol always="true">21</defaultcontrol>
    <controls>
{controls}
    </controls>
</window>
"""


def _ensure_xml():
    import anime_matrix
    os.makedirs(_SKIN_BASE, exist_ok=True)
    anime_matrix._write_atomic(_XML_PATH, _build_xml())


class LegalGateDialog(xbmcgui.WindowXMLDialog):
    # Patrón seguro: sin __init__ custom (WindowXMLDialog consume los args posicionales
    # para localizar el XML). El texto se inyecta por atributo tras instanciar.
    accepted = False
    _text    = ""

    def onInit(self):
        try:
            tb = self.getControl(1)
            tb.setText(self._text)
            tb.autoScroll(2000, 6000, 0)
        except Exception as exc:
            xbmc.log(f"[Anime] LegalGateDialog.onInit: {exc}", xbmc.LOGWARNING)

    def onClick(self, cid):
        if cid == 21:      # ACEPTAR
            self.accepted = True
            self.close()
        elif cid == 20:    # RECHAZAR
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):   # ESC / Back → no acepta
            self.close()


def show(text):
    """Muestra el diálogo de aviso legal animado.
    Devuelve True si el usuario aceptó, False si rechazó o cerró con ESC/Back."""
    _ensure_assets()
    _ensure_xml()
    dlg = LegalGateDialog(_XML_NAME, _ADDON_PATH, "Default", "1080i")
    dlg._text = text
    accepted = False
    try:
        dlg.doModal()
        accepted = dlg.accepted
    finally:
        del dlg
    return accepted
