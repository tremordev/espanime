# Autor: tremordev
# Construcción del menú y enrutado de acciones.

import hashlib
import json
import re
import sys
import os
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FuturesTimeout, as_completed
from datetime import datetime

sys.path.insert(0, os.path.dirname(__file__))

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import loader
import downloader
import anilist
import jikan
import unified

try:
    import resolveurl
    HAS_RESOLVEURL = True
except ImportError:
    HAS_RESOLVEURL = False

HAS_TOPZILLA = xbmc.getCondVisibility('System.AddonIsEnabled(plugin.video.topzilla)')

ADDON        = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL     = sys.argv[0]
MEDIA        = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "media")

_SRC_FOR_IDX = ("uni", "aflv", "tio", "lat", "mono")
try:
    _DEFAULT_SRC = _SRC_FOR_IDX[int(ADDON.getSetting("default_src"))]
except (TypeError, ValueError, IndexError):
    _DEFAULT_SRC = "uni"
try:
    EPISODES_PER_PAGE = (50, 100, 150)[int(ADDON.getSetting("episodes_per_page"))]
except (TypeError, ValueError, IndexError):
    EPISODES_PER_PAGE = 100
_ANILIST_ON = ADDON.getSetting("anilist_enabled") != "false"
_LIST_CACHE_ON = ADDON.getSetting("list_cache_enabled") != "false"
try:
    _EP_CACHE_HOURS = (0, 1, 2, 6, 12, 24)[int(ADDON.getSetting("episodes_cache_hours"))]
except (TypeError, ValueError, IndexError):
    _EP_CACHE_HOURS = 2
try:
    _PREFERRED_LANG = ("", "latino", "castellano", "subtitulado")[int(ADDON.getSetting("preferred_lang"))]
except (TypeError, ValueError, IndexError):
    _PREFERRED_LANG = ""
_UPNEXT_ON          = ADDON.getSetting("upnext_enabled") != "false"
_EPISODES_NEWEST_FIRST = ADDON.getSetting("episodes_newest_first") == "true"
_DYNAMIC_ORDER_ON   = ADDON.getSetting("dynamic_server_ordering") == "true"
_FAST_MODE          = ADDON.getSetting("fast_mode") == "true"
_ADDON_FANART = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "fanart.jpg")

_SOURCES = {
    "aflv": {"name": "Catálogo 1", "scraper": "AnimeFLVScraper",    "filters": True},
    "tio":  {"name": "Catálogo 2", "scraper": "TioAnimeScraper",    "filters": False},
    "lat":  {"name": "Catálogo 3", "scraper": "LatanimeScraper",    "filters": False},
    "mono": {"name": "Catálogo 4", "scraper": "MonosChinosScraper", "filters": False},
}
_scraper_cache = {}

# Acciones del router cuyo handler instancia scrapers (vía _get_scraper o unified.uni_*).
# Solo estas exigen que el módulo esté cargado; el resto (menús estáticos, favoritos,
# anilist, descargas, ajustes) funcionan aunque el worker esté caído.
_SCRAPER_ACTIONS = frozenset({
    "search", "latest_episodes", "latest_animes", "genres_menu",
    "browse", "episodes", "servers", "smart_play", "filter_servers",
    "select_server", "browse_all", "browse_genre",   # alias legacy → _servers
})

# Orden de preferencia de servidores (menor = más arriba), por fiabilidad real.
_SERVER_PRIORITY = {
    "sw": 1, "streamwish": 1, "swish": 1,
    "filemoon": 2, "moon": 2,
    "vidhide": 3,
    "voe": 4,
    "doodstream": 5, "dood": 5, "doods": 5,
    "mp4upload": 6, "mp4": 6,
    "yourupload": 7,
    "okru": 8, "ok": 8,
    "mixdrop": 9,
    "lulustream": 10, "lulu": 10,
    "maru": 11, "mailru": 11,
    "mega": 90,
    "stape": 95, "streamtape": 95,
}
_DEFAULT_PRIORITY = 50

# Mapeo de nombres falsos/ofuscados para los servidores.
# NOTA: Esto se hace exclusivamente para complicar el rastreo
_SERVER_ALIAS = {
    "sw":          "Shenronwish",   # streamWISH → Shenron concede deseos (Dragon Ball)
    "streamwish":  "Shenronwish",
    "swish":       "Shenronwish",
    "filemoon":    "Sailorfile",    # fileMOON → Sailor Moon
    "moon":        "Sailorfile",
    "vidhide":     "Kakashivid",    # VIDeo+HIDE → Kakashi esconde la cara (Naruto)
    "voe":         "Vongola",       # VOe → VOngola (Katekyo Hitman Reborn)
    "doodstream":  "Yorozustream",  # STREAM random → Yorozuya todo-en-uno (Gintama)
    "dood":        "Yorozustream",
    "doods":       "Yorozustream",
    "mp4upload":   "Yondaimeload",  # MP4=4º → YONdaime (4º Hokage, Naruto)
    "mp4":         "Yondaimeload",
    "yourupload":  "Kiminoload",    # YOUR → Kimi no (na wa = Your Name)
    "okru":        "Saitamaru",     # OK.ru → OK de Saitama + maru cabeza (OPM)
    "ok":          "Saitamaru",
    "mixdrop":     "Tanjidrop",     # DROP → gota de agua → respiración agua Tanjiro (DS)
    "lulustream":  "Kaguyastream",  # lunar stream → Kaguya princesa de la luna
    "lulu":        "Kaguyastream",
    "maru":        "Ichimaru",      # MARU → Ichi-MARU Gin (Bleach)
    "mailru":      "Ichimaru",
    "mega":        "Steinsgate",    # megaGATE → Steins;Gate
    "stape":       "Sagaratape",    # TAPE → Sagara graba táctica militar (Full Metal Panic)
    "streamtape":  "Sagaratape",
    "dsvplay":     "Daishinkan",    # Gran Sacerdote Dragon Ball Super
    "byse":        "Byakuchiki",    # BYse → BYAKUya Kuchiki (Bleach)
    "hexload":     "Hexgeass",      # HEX=maldicion → Geass=maldicion (Code Geass)
    "savefiles":   "Saifiles",      # SAVEfiles → SAI jutsu de dibujos/ficheros (Naruto)
}


def _server_label(name):
    return _SERVER_ALIAS.get(name.lower(), name)


# Estados de emisión de AniList traducidos (usados en plot y ficha de info).
_STATUS_ES = {
    "FINISHED": "Finalizado", "RELEASING": "En emisión",
    "NOT_YET_RELEASED": "Próximamente", "CANCELLED": "Cancelado",
}

# Filtros de catálogo del Servidor 1 (verificados contra el sitio).
TYPES  = [("tv", "TV"), ("movie", "Película"), ("special", "Especial"), ("ova", "OVA")]
STATUS = [("1", "En emisión"), ("2", "Finalizado"), ("3", "Próximamente")]
ORDERS = [("default", "Por defecto"), ("updated", "Recientemente actualizados"),
          ("added", "Recientemente agregados"), ("title", "Nombre (A-Z)"),
          ("rating", "Calificación")]

# Géneros de respaldo si el scrapeo dinámico falla. Slugs verificados contra el sitio.
GENRES_FALLBACK = [
    ("accion", "Acción"), ("artes-marciales", "Artes Marciales"), ("aventura", "Aventuras"),
    ("carreras", "Carreras"), ("ciencia-ficcion", "Ciencia Ficción"), ("comedia", "Comedia"),
    ("demencia", "Demencia"), ("demonios", "Demonios"), ("deportes", "Deportes"),
    ("drama", "Drama"), ("ecchi", "Ecchi"), ("escolares", "Escolares"), ("espacial", "Espacial"),
    ("fantasia", "Fantasía"), ("harem", "Harem"), ("historico", "Historico"),
    ("infantil", "Infantil"), ("josei", "Josei"), ("juegos", "Juegos"), ("magia", "Magia"),
    ("mecha", "Mecha"), ("militar", "Militar"), ("misterio", "Misterio"), ("musica", "Música"),
    ("parodia", "Parodia"), ("policia", "Policía"), ("psicologico", "Psicológico"),
    ("recuentos-de-la-vida", "Recuentos de la vida"), ("romance", "Romance"),
    ("samurai", "Samurai"), ("seinen", "Seinen"), ("shoujo", "Shoujo"), ("shounen", "Shounen"),
    ("sobrenatural", "Sobrenatural"), ("superpoderes", "Superpoderes"), ("suspenso", "Suspenso"),
    ("terror", "Terror"), ("vampiros", "Vampiros"), ("yaoi", "Yaoi"), ("yuri", "Yuri"),
]


# UTILIDADES

def _url(**kwargs):
    return f"{BASE_URL}?{urllib.parse.urlencode(kwargs)}"


def _topzilla_ctx(query):
    if not HAS_TOPZILLA:
        return []
    tz_url = "plugin://plugin.video.topzilla/?{}".format(
        urllib.parse.urlencode({"action": "search_alt_prompt", "q": query, "mode": "show"})
    )
    return [("[B]Buscar en TopZilla[/B]", f"RunPlugin({tz_url})")]


def _topzilla_add_ctx(title, thumb, synopsis, year):
    if not HAS_TOPZILLA:
        return []
    ref = {
        'title':      title,
        'media_type': 'show',
        'year':       year or 0,
        'poster':     thumb or '',
        'plot':       synopsis or '',
        'tmdb_id':    None,
        'imdb_id':    None,
        'source':     'espanime',
        'added_at':   int(time.time()),
    }
    ref_enc = urllib.parse.quote(json.dumps(ref, ensure_ascii=False), safe='')
    fav_url = 'plugin://plugin.video.topzilla/?' + urllib.parse.urlencode(
                  {'action': 'add_favorite',  'ref': ref_enc})
    wl_url  = 'plugin://plugin.video.topzilla/?' + urllib.parse.urlencode(
                  {'action': 'add_watchlist', 'ref': ref_enc})
    return [
        ("[B]Añadir a favoritos de TopZilla[/B]", f"RunPlugin({fav_url})"),
        ("[B]Añadir a watchlist de TopZilla[/B]", f"RunPlugin({wl_url})"),
    ]


def _icon(name):
    path = os.path.join(MEDIA, name)
    if os.path.exists(path):
        return path
    fallback = os.path.join(MEDIA, "anime_icon.png")
    return fallback if os.path.exists(fallback) else path


def _name(src):
    if src == "uni":
        return "Modo Unificado"
    entry = _SOURCES.get(src) or _SOURCES.get(_DEFAULT_SRC) or next(iter(_SOURCES.values()))
    return entry["name"]


def _get_scraper(src):
    # 'uni' no es un scraper único: cualquier ruta uni debe pasar por unified.py.
    # Lanzar aquí convierte un olvido en crash ruidoso (no en single-source silencioso).
    if src == "uni":
        raise ValueError("'uni' no tiene scraper único; usar unified.py")
    if src not in _scraper_cache:
        entry = _SOURCES.get(src) or _SOURCES.get(_DEFAULT_SRC) or next(iter(_SOURCES.values()))
        mod = loader.get()
        if mod is None:
            raise RuntimeError(f"[Anime] scrapers no disponibles (fuente: {src!r})")
        _scraper_cache[src] = getattr(mod, entry["scraper"])()
    return _scraper_cache[src]


def _to_int(value, default=0):
    """Convierte un parámetro de URL a int sin romper ante valores corruptos."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _data_dir():
    return xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.espanime/")


def _load_json(name):
    try:
        with open(os.path.join(_data_dir(), name), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def _save_json(name, data):
    # Escritura atómica: si Kodi muere a mitad, el .tmp se descarta y el fichero
    # original (favoritos/historial) queda intacto. Sin esto, una escritura
    # interrumpida dejaría JSON truncado y _load_json devolvería {} (datos perdidos).
    path = os.path.join(_data_dir(), name)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except OSError as exc:
        xbmc.log(f"[Anime] Error guardando {name}: {exc}", xbmc.LOGWARNING)


# Caché en disco de listas de episodios scrapeadas. Kodi re-ejecuta el plugin al
# reentrar a un anime (cacheToDisc solo acelera el botón Atrás), así que sin esto cada
# entrada re-scrapea la web. Con TTL configurable (ajuste "Recordar listas de episodios").

def _ep_cache_path(src, ident):
    key = hashlib.md5(f"{src}:{ident}".encode("utf-8")).hexdigest()
    return os.path.join(_data_dir(), "episodes_cache", key + ".json")


def _ep_cache_get(src, ident):
    if _EP_CACHE_HOURS <= 0:
        return None
    try:
        with open(_ep_cache_path(src, ident), encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("_ts", 0) < _EP_CACHE_HOURS * 3600:
            return obj.get("data")
    except (OSError, ValueError):
        pass
    return None


def _ep_cache_set(src, ident, data):
    if _EP_CACHE_HOURS <= 0:
        return
    path = _ep_cache_path(src, ident)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"_ts": time.time(), "data": data}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as exc:
        xbmc.log(f"[Anime] ep_cache_set: {exc}", xbmc.LOGWARNING)


def _ep_cache_clear():
    """Borra la caché de listas de episodios. Devuelve cuántos archivos eliminó."""
    cache_dir = os.path.join(_data_dir(), "episodes_cache")
    removed = 0
    try:
        if not os.path.isdir(cache_dir):
            return 0
        for fname in os.listdir(cache_dir):
            if fname.endswith(".json"):
                try:
                    os.remove(os.path.join(cache_dir, fname))
                    removed += 1
                except OSError:
                    pass
    except OSError as exc:
        xbmc.log(f"[Anime] ep_cache_clear: {exc}", xbmc.LOGWARNING)
    return removed


def _legal_read():
    path = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "AVISO_LEGAL.txt")
    try:
        # utf-8-sig: el .txt es editable por el usuario en Windows y Notepad puede
        # reguardarlo con BOM; -sig lo descarta en vez de mostrar ﻿ al inicio.
        with open(path, encoding="utf-8-sig") as f:
            return f.read()
    except (OSError, UnicodeDecodeError):
        return (
            "Este addon no aloja ni distribuye contenido. Actúa como interfaz de presentación "
            "entre Kodi y sitios web públicos de terceros.\n\n"
            "Sin ánimo de lucro. El usuario es responsable del uso que haga del software."
        )


def _legal_accepted():
    return os.path.exists(os.path.join(_data_dir(), ".legal_accepted"))


def _save_acceptance():
    try:
        os.makedirs(_data_dir(), exist_ok=True)
        path = os.path.join(_data_dir(), ".legal_accepted")
        data = {"accepted_at": int(time.time()), "addon_version": ADDON.getAddonInfo("version")}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except OSError as exc:
        xbmc.log(f"[Anime] No se pudo guardar aceptación legal: {exc}", xbmc.LOGWARNING)


def _legal_gate():
    """True si se puede continuar; False solo si el usuario RECHAZA explícitamente.

    Ante cualquier fallo técnico (diálogo no disponible, IO, etc.) devuelve True
    (fail-open): el gate es una capa extra de consentimiento; el <disclaimer> de
    addon.xml y AVISO_LEGAL.txt ya cubren lo legal, así que un bug del gate NUNCA
    debe impedir arrancar el addon.
    """
    try:
        if _legal_accepted():
            return True
        import legal_scroll
        import anime_matrix
        bg = None
        accepted = False
        try:
            bg = anime_matrix.get_icon_bg_dialog()
            if bg:
                bg.show()
            accepted = legal_scroll.show(_legal_read())
        finally:
            if bg:
                try:
                    bg.close()
                except Exception:
                    pass
        if not accepted:
            return False
        _save_acceptance()
        return True
    except Exception as exc:
        xbmc.log(f"[Anime] Fallo en gate legal, se continúa (fail-open): {exc}", xbmc.LOGWARNING)
        return True


def _revoke_legal():
    if not xbmcgui.Dialog().yesno(
        "Revocar aceptación",
        "El addon pedirá aceptar el aviso la próxima vez que lo abras.\n\n¿Confirmas?",
    ):
        return
    path = os.path.join(_data_dir(), ".legal_accepted")
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass
    xbmcgui.Dialog().notification("Espanime", "Aceptación revocada.", xbmcgui.NOTIFICATION_INFO, 3000)
    _end(succeeded=False)


def _fav_key(src, id_or_srcs):
    return f"uni:{id_or_srcs}" if src == "uni" else f"{src}:{id_or_srcs}"


def _push_recent(src, id_or_srcs, title, thumbnail):
    key   = _fav_key(src, id_or_srcs)
    items = _load_json("recently_viewed.json")
    if not isinstance(items, list):
        items = []
    items = [x for x in items if x.get("key") != key]
    items.insert(0, {
        "key":       key,
        "title":     title,
        "thumbnail": thumbnail,
        "src":       src,
        "id":        id_or_srcs if src != "uni" else "",
        "srcs":      id_or_srcs if src == "uni" else None,
    })
    _save_json("recently_viewed.json", items[:20])


def _load_recent():
    data = _load_json("recently_viewed.json")
    return data if isinstance(data, list) else []


def _update_recent_ep(anime_title, ep_num):
    items = _load_recent()
    for item in items:
        if item.get("title") == anime_title:
            if item.get("last_ep") == ep_num:
                return                       # ya registrado: evita escritura inútil
            item["last_ep"] = ep_num
            _save_json("recently_viewed.json", items)
            return


_FANART_STATE_FILE = "fanart_state.json"


def _fanart_state():
    return _load_json(_FANART_STATE_FILE)


def _is_fanart_disabled():
    return _fanart_state().get("disabled", True)


def _get_custom_fanart():
    p = _fanart_state().get("path", "")
    return p if (p and os.path.isfile(p)) else ""


def _save_fanart_state(**kwargs):
    state = _fanart_state()
    state.update(kwargs)
    _save_json(_FANART_STATE_FILE, state)


def _addon_fanart():
    state = _fanart_state()  # una sola lectura de disco por llamada
    if state.get("disabled", True):
        return ""
    p = state.get("path", "")
    if p and os.path.isfile(p):
        return p
    return _ADDON_FANART if os.path.exists(_ADDON_FANART) else ""


def _set_section_fanart(anime_fanart=""):
    # Fondo a nivel de contenedor; el fanart por ítem (setArt) lo complementa porque
    # setPluginFanart no es fiable en todos los skins.
    img = anime_fanart or _addon_fanart()
    if img:
        xbmcplugin.setPluginFanart(ADDON_HANDLE, image=img)


def _manage_fanart():
    disabled = _is_fanart_disabled()
    custom   = _get_custom_fanart()

    labels  = ["[B]Cambiar imagen personalizada[/B]" if custom else "[B]Elegir imagen personalizada[/B]"]
    actions = [_pick_fanart]
    if custom:
        labels.append("[B]Quitar imagen personalizada[/B]")
        actions.append(_clear_fanart_img)
    labels.append(
        "[B][COLOR green]Mostrar fondo de pantalla[/COLOR][/B]" if disabled
        else "[B][COLOR orange]Ocultar fondo de pantalla[/COLOR][/B]"
    )
    actions.append(_toggle_fanart)

    opt = xbmcgui.Dialog().select("Fondo de pantalla", labels)
    if opt >= 0:
        actions[opt]()


def _pick_fanart():
    current = _get_custom_fanart()
    path = xbmcgui.Dialog().browse(
        1, "Seleccionar imagen de fondo", "files",
        ".jpg|.jpeg|.png|.gif|.bmp", False, False, current or ""
    )
    if path and os.path.isfile(path):
        _save_fanart_state(path=path, disabled=False)
        xbmcgui.Dialog().notification("Espanime", "Imagen de fondo guardada",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin("Container.Refresh")


def _clear_fanart_img():
    _save_fanart_state(path="")
    xbmcgui.Dialog().notification("Espanime", "Imagen personalizada eliminada",
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_fanart():
    new_state = not _is_fanart_disabled()
    _save_fanart_state(disabled=new_state)
    msg = "Fondo de pantalla desactivado" if new_state else "Fondo de pantalla activado"
    xbmcgui.Dialog().notification("Espanime", msg, xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def _add_item(label, url, icon=None, thumbnail="", fanart=None, info=None,
              is_folder=True, is_playable=False, context=None):
    li = xbmcgui.ListItem(label=label)
    art = {}
    if thumbnail:
        art.update({"thumb": thumbnail, "poster": thumbnail})
    effective_fanart = fanart if fanart is not None else _addon_fanart()
    if effective_fanart:
        art["fanart"] = effective_fanart
    if icon:
        art["icon"] = icon
        if not thumbnail:
            art["thumb"] = icon
    if art:
        li.setArt(art)
    if info:
        li.setInfo("video", info)
    if is_playable:
        li.setProperty("IsPlayable", "true")
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=is_folder)


def _end(succeeded=True, content_type=None, cache=False, update_listing=False):
    if content_type:
        xbmcplugin.setContent(ADDON_HANDLE, content_type)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=succeeded,
                              updateListing=update_listing,
                              cacheToDisc=cache and _LIST_CACHE_ON)


def _params():
    qs = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    return dict(urllib.parse.parse_qsl(qs))


_TITLE_CLEAN_RE = re.compile(
    r'(\s+S\d+)?(\s+(latino|castellano|subtitulado|redoblaje|sub|dub))+$',
    re.IGNORECASE,
)


def _anilist_title(title):
    """Quita temporada (S1, S2…) y sufijos de idioma para que AniList encuentre el título."""
    return _TITLE_CLEAN_RE.sub("", title).strip()


def _add_anime_list(animes, src, enrich_network=True):
    """
    Renderiza una lista de animes con metadatos de AniList. Si enrich_network=True,
    precalienta la caché en bloque (enrich_many: pocas peticiones vía aliases GraphQL)
    antes del bucle, de modo que cada ítem lee de caché. En modo unificado se pasa
    False: solo caché, sin red (el fanart se rellena al abrir cada anime una vez).
    """
    favs = _load_json("favorites.json")
    if _ANILIST_ON and enrich_network and not _FAST_MODE:
        # Una sola tanda de peticiones para toda la página (no una por anime).
        anilist.enrich_many(
            [_anilist_title(a.get("title", "")) for a in animes if not a.get("synopsis")]
        )
    for anime in animes:
        title = anime.get("title", "")
        thumb = anime.get("thumbnail", "")
        plot  = anime.get("synopsis", "")
        al_title = _anilist_title(title)
        rich = anilist.get_cached(al_title) if _ANILIST_ON else {}
        fanart = rich.get("fanart", "") or _addon_fanart()
        if not plot:
            plot = rich.get("plot", "") or rich.get("plot_en", "")

        synopsis = plot
        year     = rich.get("year", 0)

        if rich:
            extras = []
            if rich.get("score"):
                extras.append(f"{rich['score'] / 10:.1f}/10")
            if rich.get("genres"):
                extras.append(", ".join(rich["genres"][:5]))
            if rich.get("studio"):
                extras.append(rich["studio"])
            if rich.get("status"):
                extras.append(_STATUS_ES.get(rich["status"], rich["status"]))
            if extras:
                prefix = "[COLOR FFDAA520]" + "  •  ".join(extras) + "[/COLOR]"
                plot = f"{prefix}\n\n{plot}" if plot else prefix

        is_uni  = "sources" in anime
        src_fav = "uni" if is_uni else src
        id_fav  = unified.encode_sources(anime["sources"]) if is_uni else anime.get("id", "")
        key     = _fav_key(src_fav, id_fav)
        fav_label = "Quitar de favoritos" if key in favs else "Añadir a favoritos"
        context = [
            (f"[B]{fav_label}[/B]",
             f"RunPlugin({_url(action='toggle_fav', src=src_fav, id=id_fav, title=title, thumbnail=thumb)})"),
            ("[B]Ver información[/B]",
             f"RunPlugin({_url(action='anime_info', title=title)})"),
        ]
        if _ANILIST_ON:
            # RunPlugin para acciones que abren diálogo; Container.Update para las que
            # construyen un directorio (con RunPlugin la lista se crearía y no se vería).
            context += [
                ("[B]Estadísticas[/B]",  f"RunPlugin({_url(action='anime_stats', title=title)})"),
                ("[B]Reseñas[/B]",       f"RunPlugin({_url(action='anime_reviews', title=title)})"),
                ("[B]Relacionados[/B]",  f"Container.Update({_url(action='anime_related', title=title)})"),
                ("[B]Recomendados[/B]",  f"Container.Update({_url(action='anime_recommended', title=title)})"),
            ]
        context += [*_topzilla_ctx(title), *_topzilla_add_ctx(title, thumb, synopsis, year)]

        li = xbmcgui.ListItem(label=f"[B]{title}[/B]")
        art = {"thumb": thumb, "poster": thumb}
        if fanart:
            art["fanart"] = fanart
        li.setArt(art)
        info = {
            "title":     title,
            "plot":      plot,
            "mediatype": "tvshow",
            "year":      year,
        }
        if rich.get("genres"):
            info["genre"] = " / ".join(rich["genres"][:5])
        if rich.get("score"):
            info["rating"] = rich["score"] / 10
        li.setInfo("video", info)
        li.addContextMenuItems(context)
        if is_uni:
            target = _url(action="episodes", src="uni",
                          srcs=unified.encode_sources(anime["sources"]), page=0)
        else:
            target = _url(action="episodes", src=src, anime_path=anime.get("id", ""), page=0)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, target, li, isFolder=True)


# REPRODUCCIÓN Y DESCARGA

def _resolve_one(video_url):
    """Resuelve un embed a URL directa con ResolveURL. None si no se puede."""
    if not HAS_RESOLVEURL:
        return None
    try:
        hmf = resolveurl.HostedMediaFile(url=video_url)
        if hmf:
            result = hmf.resolve()
            if result and isinstance(result, str):
                return result
    except Exception as exc:
        xbmc.log(f"[Anime] ResolveURL: {exc}", xbmc.LOGWARNING)
    return None


def _build_play_item(resolved):
    """Construye el ListItem reproducible a partir de la URL resuelta (HLS o directo)."""
    # ResolveURL puede anexar cabeceras: url|User-Agent=..&Referer=..
    stream_url, _, header_str = resolved.partition("|")
    is_hls = ".m3u8" in stream_url.lower() or "mpegurl" in stream_url.lower()

    if is_hls:
        # inputstream.adaptive reproduce HLS con bitrate adaptativo: elige una
        # calidad que no se atasca en lugar de bufferear con el demuxer ffmpeg.
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setMimeType("application/vnd.apple.mpegurl")
        play_item.setContentLookup(False)
        play_item.setProperty("inputstream", "inputstream.adaptive")
        play_item.setProperty("inputstream.adaptive.manifest_type", "hls")  # compat ISA 20
        if header_str:
            play_item.setProperty("inputstream.adaptive.stream_headers", header_str)
            play_item.setProperty("inputstream.adaptive.manifest_headers", header_str)
    else:
        # mp4/otros: el curl de Kodi maneja la sintaxis url|cabeceras directamente
        play_item = xbmcgui.ListItem(path=resolved)

    play_item.setProperty("IsPlayable", "true")
    return play_item


def _warn_no_resolveurl():
    xbmcgui.Dialog().ok(
        "ResolveURL no instalado",
        "Para reproducir necesitas instalar el módulo ResolveURL.\n\n"
        "Ve a: Complementos → Instalar desde repositorio → "
        "Repositorio de complementos de Kodi → Módulos → ResolveURL.",
    )
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())


def _store_playlist(entries):
    """Guarda la lista ordenada de episodios del anime abierto (n/título/url de
    reproducción) en una Window Property, para que _prime_nowplaying sepa cuál es
    el siguiente y service.py pueda alimentar a Up Next."""
    try:
        xbmcgui.Window(10000).setProperty("espanime.playlist", json.dumps(entries))
    except Exception:
        pass


def _prime_nowplaying(title):
    """Deja {anime, episode, next?} en una Window Property: service.py lo lee para
    AniSkip (marcas op/ed) y Up Next (siguiente episodio). Barato (sin red)."""
    if not title:
        return
    ep_m = re.search(r'[\s\-—]+(\d+)\s*$', title)
    cur  = int(ep_m.group(1)) if ep_m else 0
    # ts: el servicio descarta propiedades viejas (p.ej. de un play que resolvió pero
    # nunca arrancó), para no actuar sobre un vídeo ajeno reproducido más tarde.
    prop = {"anime": _anime_title_from_ep(title), "episode": cur, "ts": int(time.time())}
    if _UPNEXT_ON and ep_m is not None:   # ep_m presente: número real (incluye ep 0)
        try:
            pl = json.loads(xbmcgui.Window(10000).getProperty("espanime.playlist") or "[]")
            # La playlist se guarda al abrir el anime (página 0). Con la caché de listas,
            # volver a una lista cacheada no la regenera, así que podría pertenecer a otro
            # anime abierto después: solo la usamos si es del mismo anime que se reproduce.
            if pl and _anime_title_from_ep(pl[0].get("t", "")) != prop["anime"]:
                pl = []
            for i, e in enumerate(pl):
                if _to_int(e.get("n"), -1) == cur and i + 1 < len(pl):
                    nxt = pl[i + 1]
                    prop["next"] = {"title": nxt.get("t", ""),
                                    "num": _to_int(nxt.get("n"), 0),
                                    "url": nxt.get("u", "")}
                    break
        except Exception:
            pass
    try:
        xbmcgui.Window(10000).setProperty("espanime.nowplaying", json.dumps(prop))
    except Exception:
        pass


def _resolve_and_play(video_url, title="", server=""):
    if not HAS_RESOLVEURL:
        _warn_no_resolveurl()
        return
    resolved = _resolve_one(video_url)
    if not resolved:
        _record_server_result(server, False)
        xbmcgui.Dialog().notification(
            "Anime", "Servidor no disponible. Vuelve y prueba otro.",
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return
    _record_server_result(server, True)
    _prime_nowplaying(title)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=_build_play_item(resolved))


def _smart_play(playable, name, title=""):
    """Reproduce el primer servidor (ya ordenado por prioridad) que resuelva, sin
    que el usuario elija. Si todos fallan, avisa. Es el fallover invisible."""
    if not HAS_RESOLVEURL:
        _warn_no_resolveurl()
        return
    for s in playable:
        url = s.get("url", "")
        server = s.get("server", "")
        resolved = url if s.get("direct") else _resolve_one(url)
        if resolved:
            _record_server_result(server, True)
            _prime_nowplaying(title)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=_build_play_item(resolved))
            return
        _record_server_result(server, False)
    xbmcgui.Dialog().notification(name, "Ningún servidor disponible ahora.",
                                  xbmcgui.NOTIFICATION_WARNING, 4000)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())


def _probe_one(server):
    """True si el servidor responde (resuelve a una URL reproducible). Los directos
    no pasan por ResolveURL: se asumen vivos (su URL ya es el stream final)."""
    url = server.get("url", "")
    if not url:
        return False
    if server.get("direct"):
        return True
    return bool(_resolve_one(url))


_PROBE_MAX_SECONDS = 25   # techo global: un resolver que no contesta en este margen


def _probe_servers(servers):
    """Resuelve los servidores en paralelo y devuelve solo los que responden, con
    barra de progreso cancelable. Devuelve None si el usuario cancela (el caller deja
    la lista intacta). Cada resultado alimenta server_stats (ordenación dinámica)."""
    total = len(servers)
    prog  = xbmcgui.DialogProgress()
    prog.create("Comprobar servidores",
                "Resolviendo enlaces, esto puede tardar unos segundos…")
    alive, done = [], 0
    # max_workers acotado: resolver no debe abrir 20 conexiones a hosts de vídeo a la
    # vez (riesgo de rate-limit/anti-bot). 6 equilibra rapidez y prudencia.
    ex = ThreadPoolExecutor(max_workers=max(1, min(6, total)))
    try:
        futures = {ex.submit(_probe_one, s): s for s in servers}
        try:
            # Techo global: si un resolver no contesta nunca, no se cuelga la operación
            # esperándolo (los pendientes se tratan como "no responde").
            for fut in as_completed(futures, timeout=_PROBE_MAX_SECONDS):
                if prog.iscanceled():
                    return None
                done += 1
                try:
                    ok = fut.result()
                except Exception:
                    ok = False
                s = futures[fut]
                if ok:
                    alive.append(s)
                _record_server_result(s.get("server", ""), ok)
                prog.update(int(done / total * 100),
                            f"{done}/{total} comprobados  ·  {len(alive)} funcionan")
        except _FuturesTimeout:
            xbmc.log(f"[Anime] probe_servers: techo de {_PROBE_MAX_SECONDS}s, "
                     f"{total - done} servidor(es) sin respuesta descartados", xbmc.LOGWARNING)
    finally:
        ex.shutdown(wait=False)   # un resolver colgado drena en background, no bloquea
        prog.close()
    return alive


# MENÚS

def _main_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Anime")
    _set_section_fanart()
    # Orden de catálogos; el preferido (ajuste "Catálogo por defecto") va primero.
    catalogs = [
        ("uni",  "Modo Unificado", "unified.png"),
        ("aflv", "Catálogo 1",     "animeflv.png"),
        ("tio",  "Catálogo 2",     "goku.png"),
        ("lat",  "Catálogo 3",     "luffy.png"),
        ("mono", "Catálogo 4",     "totoro.png"),
    ]
    catalogs.sort(key=lambda c: c[0] != _DEFAULT_SRC)   # estable: el preferido al frente
    for src_id, label, icon in catalogs:
        _add_item(f"[B]{label}[/B]", _url(action="home", src=src_id), icon=_icon(icon))
    _add_item("[B]Emisión semanal[/B]", _url(action="airing_schedule"), icon=_icon("latest_eps.png"))
    _add_item("[B]Descargas[/B]",     _url(action="downloads"),    icon=_icon("downloads.png"))
    _add_item("[B]Configuración[/B]", _url(action="open_settings"), icon=_icon("settings.png"), is_folder=False)
    _end()


def _home(src):
    if src == "uni":
        return _uni_home()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, _name(src))
    _set_section_fanart()
    _add_item("[B]Mis Favoritos[/B]",       _url(action="favorites"),                icon=_icon("heart.png"))
    _add_item("[B]Continuar viendo[/B]",    _url(action="recent"),                   icon=_icon("history.png"))
    _add_item("[B]Buscar[/B]",              _url(action="search", src=src),          icon=_icon("search.png"))
    _add_item("[B]Últimos Episodios[/B]",   _url(action="latest_episodes", src=src), icon=_icon("latest_eps.png"))
    _add_item("[B]Últimos Animes[/B]",      _url(action="latest_animes", src=src),   icon=_icon("latest_animes.png"))
    _add_item("[B]Todos los animes[/B]",    _url(action="browse", src=src, kind="order", val="default", page=1),
              icon=_icon("catalog.png"))
    if _SOURCES[src]["filters"]:
        _add_item("[B]Por Letra[/B]",       _url(action="letter_menu", src=src),  icon=_icon("order.png"))
        _add_item("[B]Por Género[/B]",      _url(action="genres_menu", src=src),  icon=_icon("genres.png"))
        _add_item("[B]Por Tipo[/B]",        _url(action="types_menu", src=src),   icon=_icon("types.png"))
        _add_item("[B]Por Estado[/B]",      _url(action="status_menu", src=src),  icon=_icon("status.png"))
        _add_item("[B]Por Año[/B]",         _url(action="year_menu", src=src),    icon=_icon("year.png"))
        _add_item("[B]Ordenar / Explorar[/B]", _url(action="order_menu", src=src), icon=_icon("order.png"))
    _end()


# Margen tras cerrar el directorio antes de reescribir la ruta con Container.Update.
# Si el Update llega mientras Kodi aún está cambiando de contenedor, lo descarta
# ("updating in progress" / "GetDirectory failed" en kodi.log) y el usuario se queda
# en pantalla vacía. Valor tomado de plugin.video.netflix (search_add), que documenta
# esta misma carrera "change the container path too fast".
_SEARCH_REDIRECT_DELAY_MS = 1000


def _search(src, query=None, browse=False):
    # browse=True: navegación normal desde una lista (recomendados, calendario…); cierra
    # con update_listing=False para que Atrás vuelva a esa lista. browse=False: flujo del
    # placeholder "Buscando…", que reemplaza su propia entrada (update_listing=True).
    if query is None:
        hist    = _load_json("search_history.json")
        hist    = hist if isinstance(hist, list) else []
        choices = ["Nueva búsqueda..."] + hist
        idx     = xbmcgui.Dialog().select(f"Buscar en {_name(src)}", choices)
        if idx < 0:
            _end(succeeded=False)
            return
        if idx == 0:
            query = xbmcgui.Dialog().input("Buscar anime", type=xbmcgui.INPUT_ALPHANUM).strip()
        else:
            query = hist[idx - 1].strip()
        if not query:
            _end(succeeded=False)
            return
        updated = [q for q in hist if q != query]
        updated.insert(0, query)
        _save_json("search_history.json", updated[:10])
        # Reescribimos la ruta del contenedor a la URL con la query incrustada para
        # que Container.Refresh (tras añadir a favoritos) no reabra el diálogo. No se
        # puede lanzar Container.Update desde un directorio vacío ni de inmediato: hay
        # que cerrar un directorio VÁLIDO y dejar un margen, o Kodi descarta el Update.
        # Mostramos un placeholder (que además navega a los resultados si se pulsa).
        # Container.Update SIN ,replace: el flag replace borra el historial hasta la
        # raíz (Back saltaría al menú principal). En su lugar la fase query cierra con
        # updateListing=True, que reemplaza solo la entrada del placeholder; así Back
        # vuelve al menú de la fuente. Patrón de plugin.video.netflix.
        query_url = _url(action="search", src=src, query=query)
        placeholder = xbmcgui.ListItem(label=f"[B]Buscando: {query}[/B]")
        placeholder.setArt({"icon": _icon("search.png")})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, query_url, placeholder, isFolder=True)
        _end(succeeded=True)
        xbmc.sleep(_SEARCH_REDIRECT_DELAY_MS)
        xbmc.executebuiltin(f"Container.Update({query_url})")
        return

    if not query:
        # Defensivo: parse_qsl omite ?query= vacío (keep_blank_values=False por
        # defecto), así que en la práctica query nunca es "" aquí. Guard por si
        # algún futuro call-site pasa "" directamente.
        _end(succeeded=False)
        return

    if src == "uni":
        return _uni_search(query, browse)

    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Búsqueda: {query}")
    _set_section_fanart()
    results = _get_scraper(src).search(query)
    if not results:
        xbmcgui.Dialog().notification(_name(src), f"Sin resultados para: {query}",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        # En modo browse, fallar (succeeded=False) deja al usuario en la lista de origen.
        # En el flujo placeholder, succeeded=True + update_listing reemplaza el "Buscando…".
        _end(succeeded=not browse, update_listing=not browse)
        return
    _add_anime_list(results, src)
    _end(content_type="tvshows", update_listing=not browse)


def _anime_title_from_ep(ep_title):
    """
    Extrae el título del anime desde el título del episodio.
    Servidor 1: 'One Piece — Episodio 1164'  → 'One Piece'
    Servidor 2: 'One Piece 1164'             → 'One Piece'
               'Isekai Nonbiri Nouka 2 9'   → 'Isekai Nonbiri Nouka 2'
    """
    # Servidor 1 y similares: separador explícito
    for sep in (" — Episodio", " - Episodio", " — Capítulo", " - Capítulo"):
        if sep in ep_title:
            return ep_title.split(sep)[0].strip()
    # Servidor 2: número suelto al final (una o más cifras, posible espacio antes)
    cleaned = re.sub(r"\s+\d+\s*$", "", ep_title).strip()
    return cleaned or ep_title.strip()


def _latest_episodes(src):
    if src == "uni":
        return _uni_latest_episodes()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Últimos Episodios")
    _set_section_fanart()
    episodes = _get_scraper(src).get_latest_episodes()
    if not episodes:
        xbmcgui.Dialog().notification(_name(src), "No se pudieron obtener los últimos episodios.",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        _end(succeeded=False)
        return
    seen = {}   # evita llamadas duplicadas si el mismo anime aparece varias veces
    for ep in episodes:
        anime_name = _anime_title_from_ep(ep["title"])
        if anime_name not in seen:
            seen[anime_name] = anilist.enrich(anime_name) if _ANILIST_ON else {}
        rich   = seen[anime_name]
        fanart = rich.get("fanart", "") or _addon_fanart()
        plot   = rich.get("plot", "") or rich.get("plot_en", "")
        thumb  = ep["thumbnail"]

        li = xbmcgui.ListItem(label=f"[B]{ep['title']}[/B]")
        art = {"thumb": thumb, "poster": thumb, "icon": _icon("play.png")}
        if fanart:
            art["fanart"] = fanart
        li.setArt(art)
        score  = rich.get("score", 0)
        genres = rich.get("genres", [])
        li.setInfo("video", {
            "title":       ep["title"],
            "tvshowtitle": anime_name,
            "plot":        plot,
            "mediatype":   "episode",
            "rating":      score / 10.0 if score else 0,
            "genre":       ", ".join(genres[:3]) if genres else "",
        })
        li.addContextMenuItems([
            ("[B]Descargar (elegir servidor)[/B]",
             f"RunPlugin({_url(action='servers', src=src, ep_url=ep['url'], title=ep['title'], mode='download')})"),
            *_topzilla_ctx(anime_name),
            *_topzilla_add_ctx(anime_name, thumb, plot, rich.get("year", 0)),
        ])
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            _url(action="servers", src=src, ep_url=ep["url"], title=ep["title"]),
            li, isFolder=True,
        )
    _end(content_type="episodes")


def _latest_animes(src):
    if src == "uni":
        return _uni_latest_animes()
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Últimos Animes")
    _set_section_fanart()
    animes = _get_scraper(src).get_latest_animes()
    if not animes:
        xbmcgui.Dialog().notification(_name(src), "No se pudieron obtener los últimos animes.",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        _end(succeeded=False)
        return
    _add_anime_list(animes, src)
    _end(content_type="tvshows")


# submenús de filtros

def _genres_menu(src):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Géneros")
    _set_section_fanart()
    if src == "uni":
        genres, _f = unified.uni_genres()
        genres = genres or GENRES_FALLBACK
    else:
        genres = _get_scraper(src).get_genres() or GENRES_FALLBACK
    # Cada género tiene su icono temático en resources/media/g_<slug>.png
    # (descargados con tmp/download_genre_icons*.py). _icon hace fallback si falta.
    for g_id, g_name in genres:
        _add_item(f"[B]{g_name}[/B]", _url(action="browse", src=src, kind="genre", val=g_id, page=1),
                  icon=_icon(f"g_{g_id}.png"))
    _end()


def _letter_menu(src):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Por letra")
    _set_section_fanart()
    for letter in ["#"] + [chr(c) for c in range(ord("A"), ord("Z") + 1)]:
        _add_item(
            f"[B]{letter}[/B]",
            _url(action="browse", src=src, kind="letter", val=letter.lower(), page=1),
            icon=_icon("order.png"),
        )
    _end()


_TYPE_ICONS  = {"tv": "tv.png", "movie": "popcorn.png", "special": "star.png", "ova": "scroll.png"}
_STATUS_ICONS = {"1": "fire.png", "2": "done.png", "3": "calendar.png"}
_ORDER_ICONS  = {
    "default": "home.png", "updated": "latest_eps.png", "added": "latest_animes.png",
    "title": "order.png",  "rating": "star.png",
}


def _types_menu(src):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Tipos")
    _set_section_fanart()
    for t_id, t_name in TYPES:
        _add_item(f"[B]{t_name}[/B]", _url(action="browse", src=src, kind="type", val=t_id, page=1),
                  icon=_icon(_TYPE_ICONS.get(t_id, "types.png")))
    _end()


def _status_menu(src):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Estados")
    _set_section_fanart()
    for s_id, s_name in STATUS:
        _add_item(f"[B]{s_name}[/B]", _url(action="browse", src=src, kind="status", val=s_id, page=1),
                  icon=_icon(_STATUS_ICONS.get(s_id, "status.png")))
    _end()


def _year_menu(src):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Años")
    _set_section_fanart()
    for year in range(datetime.now().year, 1989, -1):
        _add_item(f"[B]{year}[/B]", _url(action="browse", src=src, kind="year", val=str(year), page=1),
                  icon=_icon("year.png"))
    _end()


def _order_menu(src):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Ordenar catálogo")
    _set_section_fanart()
    for o_id, o_name in ORDERS:
        _add_item(f"[B]{o_name}[/B]", _url(action="browse", src=src, kind="order", val=o_id, page=1),
                  icon=_icon(_ORDER_ICONS.get(o_id, "order.png")))
    _end()


def _browse(src, kind, val, page):
    scraper = _get_scraper(src)
    if kind == "genre":
        animes, nxt = scraper.browse_by_genre(val, page)
        cat = f"Género: {val}"
    elif kind == "type":
        animes, nxt = scraper.browse_by_type(val, page)
        cat = f"Tipo: {dict(TYPES).get(val, val)}"
    elif kind == "status":
        animes, nxt = scraper.browse_by_status(val, page)
        cat = f"Estado: {dict(STATUS).get(val, val)}"
    elif kind == "year":
        animes, nxt = scraper.browse_by_year(val, page)
        cat = f"Año: {val}"
    elif kind == "letter":
        label = val.upper() if val != "#" else "#"
        progress = xbmcgui.DialogProgressBG()
        progress.create("Buscando animes", f"Letra {label}…")
        try:
            animes, nxt = scraper.browse_by_letter(
                val, page,
                on_progress=lambda done, total: progress.update(
                    int(done * 100 / total), "Buscando animes", f"Letra {label} — {done}/{total}"),
            )
        finally:
            progress.close()
        cat = f"Letra: {label}"
    else:  # order
        animes, nxt = scraper.browse_all(page, order=val)
        cat = f"Catálogo: {dict(ORDERS).get(val, val)}"

    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"{cat} — pág. {page}")
    _set_section_fanart()
    _add_anime_list(animes, src)
    if nxt:
        _add_item(
            f"[B][COLOR gold]>> Página siguiente ({nxt})[/COLOR][/B]",
            _url(action="browse", src=src, kind=kind, val=val, page=nxt),
            icon=_icon("forward.png"),
        )
    _end(content_type="tvshows", cache=True)


def _episodes(src, anime_path, page):
    scraper = _get_scraper(src)
    cached  = _ep_cache_get(src, anime_path)
    if cached:
        info, all_eps = cached.get("info", {}), cached.get("episodes", [])
    else:
        info    = scraper.get_anime_info(anime_path)
        all_eps = scraper.get_episodes(anime_path)
        if all_eps:
            _ep_cache_set(src, anime_path, {"info": info, "episodes": all_eps})
    title    = info.get("title") or "Anime"
    poster   = info.get("poster", "")
    synopsis = info.get("synopsis", "")
    xbmcplugin.setPluginCategory(ADDON_HANDLE, title)

    if not all_eps:
        xbmcgui.Dialog().ok(
            _name(src),
            "No se encontraron episodios.\n"
            "Puede ser un problema de red o que el anime no esté disponible.",
        )
        _end(succeeded=False)
        return

    # Enriquece con AniList solo en la primera página (caché en disco, ~200ms 1ª vez)
    rich   = (anilist.enrich(title, synopsis, poster) if _ANILIST_ON else {}) if page == 0 else {}
    fanart  = rich.get("fanart", "") or _addon_fanart()
    poster  = rich.get("poster", "") or poster
    plot    = rich.get("plot", "") or synopsis
    score   = rich.get("score", 0)
    genres  = rich.get("genres", [])

    if page == 0 and all_eps:
        _push_recent(src, anime_path, title, poster)
        if _UPNEXT_ON:
            _store_playlist([
                {"n": str(e["number"]),
                 "t": f"{title} — {e['title']}",
                 "u": _url(action="smart_play", src=src, ep_url=e["url"],
                           title=f"{title} — {e['title']}")}
                for e in all_eps])

    if _EPISODES_NEWEST_FIRST:
        all_eps = list(reversed(all_eps))

    _set_section_fanart(fanart)

    total    = len(all_eps)
    start    = page * EPISODES_PER_PAGE
    end      = start + EPISODES_PER_PAGE
    page_eps = all_eps[start:end]

    if page > 0:
        if _EPISODES_NEWEST_FIRST:
            ps = all_eps[(page - 1) * EPISODES_PER_PAGE : page * EPISODES_PER_PAGE]
            prev_lbl = (f"[B][COLOR cyan]<< Episodios {ps[-1].get('number','?')}–{ps[0].get('number','?')}[/COLOR][/B]"
                        if ps else "[B][COLOR cyan]<< Episodios anteriores[/COLOR][/B]")
        else:
            prev_lbl = f"[B][COLOR cyan]<< Episodios {(page-1)*EPISODES_PER_PAGE+1}–{page*EPISODES_PER_PAGE}[/COLOR][/B]"
        _add_item(prev_lbl, _url(action="episodes", src=src, anime_path=anime_path, page=page - 1), icon=_icon("back.png"))

    for ep in page_eps:
        ep_title = f"{title} — {ep['title']}"
        li = xbmcgui.ListItem(label=f"[B]{ep['title']}[/B]")
        art = {"thumb": poster, "poster": poster}
        if fanart:
            art["fanart"] = fanart
        li.setArt(art)
        li.setInfo("video", {
            "title":       ep_title,
            "plot":        plot,
            "tvshowtitle": title,
            "mediatype":   "episode",
            "episode":     int(float(ep.get("number", 0) or 0)),
            "season":      1,
            "year":        rich.get("year", 0),
            "rating":      score / 10.0 if score else 0,
            "genre":       ", ".join(genres[:4]) if genres else "",
        })
        li.addContextMenuItems([
            ("[B]Descargar (elegir servidor)[/B]",
             f"RunPlugin({_url(action='servers', src=src, ep_url=ep['url'], title=ep_title, mode='download')})"),
            *_topzilla_ctx(title),
            *_topzilla_add_ctx(title, poster, plot, rich.get("year", 0)),
        ])
        xbmcplugin.addDirectoryItem(ADDON_HANDLE,
            _url(action="servers", src=src, ep_url=ep["url"], title=ep_title),
            li, isFolder=True)

    if end < total:
        if _EPISODES_NEWEST_FIRST:
            ns = all_eps[end : min(end + EPISODES_PER_PAGE, total)]
            next_lbl = f"[B][COLOR gold]>> Episodios {ns[-1].get('number','?')}–{ns[0].get('number','?')}[/COLOR][/B]"
        else:
            next_lbl = f"[B][COLOR gold]>> Episodios {end+1}–{min(end+EPISODES_PER_PAGE,total)}[/COLOR][/B]"
        _add_item(next_lbl, _url(action="episodes", src=src, anime_path=anime_path, page=page + 1), icon=_icon("forward.png"))

    _end(content_type="episodes", cache=True)


# SERVIDORES

def _supported_by_resolveurl(url):
    if not HAS_RESOLVEURL:
        return True
    try:
        return bool(resolveurl.HostedMediaFile(url=url))
    except Exception:
        return False


def _server_priority(server_name):
    return _SERVER_PRIORITY.get(server_name.lower(), _DEFAULT_PRIORITY)


_SEVEN_DAYS = 7 * 24 * 3600


def _record_server_result(server_name, success):
    if not _DYNAMIC_ORDER_ON:
        return
    key = server_name.lower()
    try:
        stats = _load_json("server_stats.json")
        if not isinstance(stats, dict):
            stats = {}
        entry = stats.get(key)
        if not isinstance(entry, dict):
            entry = {"ok": 0, "fail": 0, "last_fail": 0}
        if success:
            entry["ok"] = entry.get("ok", 0) + 1
        else:
            entry["fail"] = entry.get("fail", 0) + 1
            entry["last_fail"] = int(time.time())
        stats[key] = entry
        _save_json("server_stats.json", stats)
    except Exception as exc:
        xbmc.log(f"[Anime] _record_server_result({key}): {exc}", xbmc.LOGWARNING)


def _dynamic_server_priority(name, stats):
    """Prioridad base + penalización por tasa de fallo reciente. Solo penaliza con
    >=5 intentos y un fallo en los últimos 7 días; si no, devuelve la base estática."""
    base = _server_priority(name)
    if not stats:
        return base
    entry = stats.get(name.lower())
    if not isinstance(entry, dict):
        return base
    total = entry.get("ok", 0) + entry.get("fail", 0)
    if total < 5:
        return base
    last_fail = entry.get("last_fail", 0)
    if not last_fail or (int(time.time()) - last_fail) > _SEVEN_DAYS:
        return base
    fail_rate = entry.get("fail", 0) / total
    return base + round(fail_rate * 20)


def _filter_and_sort_servers(servers):
    """Filtra a reproducibles (directos o soportados por resolveurl) y ordena por fiabilidad.
    Si _PREFERRED_LANG está configurado, sube al top los servidores con ese idioma."""
    playable = [s for s in servers if s.get("direct") or _supported_by_resolveurl(s.get("url", ""))]
    stats = _load_json("server_stats.json") if _DYNAMIC_ORDER_ON else {}
    if not isinstance(stats, dict):
        stats = {}
    def _sort_key(s):
        lang = (s.get("language") or "").lower()
        lang_score = 0 if (_PREFERRED_LANG and _PREFERRED_LANG in lang) else 1
        prio = _dynamic_server_priority(s.get("server", ""), stats) if _DYNAMIC_ORDER_ON else _server_priority(s.get("server", ""))
        return (lang_score, prio)
    playable.sort(key=_sort_key)
    return servers, playable


def _render_servers(servers, title, mode, name, play_all_url=None, verify_url=None,
                    category="Servidores", cache=True, update_listing=False):
    """Render común de servidores (single-source y unificado). El origen [S1]/[S2]
    solo aparece si el servidor lo trae (items unificados), así el single-source
    queda idéntico. play_all_url añade el botón de reproducción automática; verify_url
    añade como segunda opción "Dejar solo los que responden". cache=False no guarda la
    lista en la caché de disco. update_listing=True reemplaza la lista de origen en el
    historial (la filtrada sustituye a la completa, así Atrás vuelve a episodios)."""
    if mode != "download" and title:
        anime_name = _anime_title_from_ep(title)
        ep_m = re.search(r'[\s\-—]+(\d+)\s*$', title)
        if anime_name and ep_m:
            _update_recent_ep(anime_name, ep_m.group(1))
    servers, playable = _filter_and_sort_servers(servers)

    if not servers:
        xbmcgui.Dialog().ok(name,
                            "No se encontraron servidores de vídeo.\n"
                            "Puede ser un problema de red o que el episodio no esté disponible.")
        if mode != "download":
            _end(succeeded=False)
        return

    if not playable:
        xbmcgui.Dialog().ok(name,
                            "Hay servidores, pero ninguno es compatible con tu ResolveURL.\n"
                            "Instala/actualiza el módulo ResolveURL.")
        if mode != "download":
            _end(succeeded=False)
        return

    if mode == "download":
        labels = [f"{_server_label(s['server'])}" + (f" [{s['origin']}]" if s.get("origin") else "")
                  + ("  [Directo]" if s.get("direct") else "") for s in playable]
        idx = xbmcgui.Dialog().select("Descargar desde…", labels)
        if idx >= 0:
            downloader.download(playable[idx]["url"], title)
        return

    xbmcplugin.setPluginCategory(ADDON_HANDLE, category)
    _set_section_fanart()
    if play_all_url and len(playable) > 1:
        _add_item(
            "[B][COLOR lime]Reproducir (automatico)[/COLOR][/B]",
            play_all_url,
            icon=_icon("play.png"),
            is_folder=False,
            is_playable=True,
        )
    if verify_url and len(playable) > 1:
        _add_item(
            "[B][COLOR gold]Dejar solo los que responden[/COLOR][/B]",
            verify_url,
            icon=_icon("done.png"),
            is_folder=True,
        )
    for s in playable:
        origin = f"  [COLOR yellow][{s['origin']}][/COLOR]" if s.get("origin") else ""
        lang   = f"  [COLOR gray]({s['language']})[/COLOR]" if s.get("language") else ""
        extra  = "  [COLOR lime][Directo][/COLOR]" if s.get("direct") else ""
        dl     = _url(action="download", video_url=s["url"], title=title)
        _add_item(
            f"[B]{_server_label(s['server'])}[/B]{origin}{lang}{extra}",
            _url(action="play", video_url=s["url"], title=title, server=s["server"]),
            icon=_icon("play.png"),
            is_folder=False,
            is_playable=True,
            context=[("[B]Descargar este servidor[/B]", f"RunPlugin({dl})")],
        )
    # No se cachea si: (a) ordenación dinámica activa (el orden depende de server_stats,
    # que cambia tras cada reproducción y debe reflejarse al reabrir), o (b) cache=False
    # (lista de la verificación, que debe rehacerse en cada pulsación, no servirse vieja).
    _end(cache=cache and not _DYNAMIC_ORDER_ON, update_listing=update_listing)


def _servers(src, ep_url, title, mode="play"):
    """Lista servidores de una fuente. mode='download' abre diálogo de descarga."""
    servers = _get_scraper(src).get_video_servers(ep_url)
    play_all = _url(action="smart_play", src=src, ep_url=ep_url, title=title)
    verify   = _url(action="filter_servers", src=src, ep_url=ep_url, title=title)
    _render_servers(servers, title, mode, _name(src), play_all, verify)


_PROBE_PROP = "espanime.probed"
_PROBE_TTL  = 15 * 60   # 15 min: dentro de la sesión se reutiliza la última comprobación


def _probe_cache_get(ep_key):
    """Resultado reciente de la comprobación para este episodio, o None. Persiste en una
    Window Property (toda la sesión de Kodi), así volver del reproductor no re-comprueba
    aunque Kodi re-ejecute el directorio."""
    try:
        data  = json.loads(xbmcgui.Window(10000).getProperty(_PROBE_PROP) or "{}")
        entry = data.get(ep_key)
        if entry and time.time() - entry.get("ts", 0) < _PROBE_TTL:
            return entry["servers"], entry.get("total", len(entry["servers"]))
    except (ValueError, KeyError, TypeError):
        pass
    return None


def _probe_cache_set(ep_key, servers, total):
    try:
        win  = xbmcgui.Window(10000)
        data = json.loads(win.getProperty(_PROBE_PROP) or "{}")
        if not isinstance(data, dict):
            data = {}
        now  = time.time()
        # Poda caducadas para que la propiedad no crezca sin límite durante la sesión.
        data = {k: v for k, v in data.items() if now - v.get("ts", 0) < _PROBE_TTL}
        data[ep_key] = {"servers": servers, "total": total, "ts": now}
        win.setProperty(_PROBE_PROP, json.dumps(data))
    except (ValueError, TypeError) as exc:
        xbmc.log(f"[Anime] probe_cache_set: {exc}", xbmc.LOGWARNING)


def _filter_servers(src, ep_url, eps, title):
    """Comprueba qué servidores responden (resolviéndolos) y muestra solo esos. Reutiliza
    el resultado reciente si lo hay (volver del reproductor no repite la comprobación)."""
    # Aquí NO se usa _warn_no_resolveurl: hace setResolvedUrl (contexto de reproducción),
    # pero esto es construcción de un directorio, no una reproducción.
    if not HAS_RESOLVEURL:
        xbmcgui.Dialog().ok("ResolveURL no instalado",
                            "Necesitas el módulo ResolveURL para comprobar los servidores.")
        _end(succeeded=False)
        return
    if src == "uni":
        ep_key   = eps
        name     = _UNI_NAME
        play_all = _url(action="smart_play", src="uni", eps=eps, title=title)
    else:
        ep_key   = ep_url
        name     = _name(src)
        play_all = _url(action="smart_play", src=src, ep_url=ep_url, title=title)

    cached = _probe_cache_get(ep_key)
    if cached is not None:
        alive, total = cached
    else:
        if src == "uni":
            eps_map = unified.decode_sources(eps)
            servers = unified.uni_servers(eps_map)[0] if eps_map else []
        else:
            servers = _get_scraper(src).get_video_servers(ep_url)
        _, playable = _filter_and_sort_servers(servers)
        if not playable:
            xbmcgui.Dialog().ok(name, "No hay servidores compatibles que comprobar.")
            _end(succeeded=False)
            return
        alive = _probe_servers(playable)
        if alive is None:                       # el usuario canceló: no tocar nada
            _end(succeeded=False)
            return
        if not alive:
            xbmcgui.Dialog().ok(name, "Ninguno de los servidores responde ahora mismo.\n"
                                      "Puede ser temporal; inténtalo de nuevo más tarde.")
            _end(succeeded=False)
            return
        total = len(playable)
        _probe_cache_set(ep_key, alive, total)
    # Sin verify_url: la lista ya filtrada no repite la opción de comprobar.
    _render_servers(alive, title, "play", name, play_all,
                    category=f"Servidores que responden ({len(alive)}/{total})",
                    update_listing=True)


# MODO UNIFICADO  (fusiona ambas fuentes; rutas aisladas, cero regresión)

_UNI_NAME = "Modo Unificado"


def _uni_all_failed(failed):
    return len(failed) >= len(_SOURCES)


def _uni_notice(failed):
    """Aviso breve si una fuente falló pero la otra respondió (resultados parciales)."""
    if failed and not _uni_all_failed(failed):
        names = ", ".join(_SOURCES[s]["name"] for s in failed if s in _SOURCES)
        if names:
            xbmcgui.Dialog().notification(_UNI_NAME, f"{names} no disponible",
                                          xbmcgui.NOTIFICATION_WARNING, 2500)


def _uni_empty(failed, msg="Sin resultados.", redirect=False):
    if _uni_all_failed(failed):
        xbmcgui.Dialog().notification(_UNI_NAME, "No se pudo conectar con ninguna fuente.",
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
    else:
        xbmcgui.Dialog().notification(_UNI_NAME, msg, xbmcgui.NOTIFICATION_INFO, 3000)
    # redirect: en la fase query del buscador el contenedor actual es el placeholder
    # "Buscando…"; hay que reemplazarlo por una lista vacía (succeeded=True + updateListing)
    # o el usuario queda clavado en él. Fuera del buscador, succeeded=False (no navega).
    if redirect:
        _end(succeeded=True, update_listing=True)
    else:
        _end(succeeded=False)


def _uni_home():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, _UNI_NAME)
    _set_section_fanart()
    _add_item("[B]Mis Favoritos[/B]",     _url(action="favorites"),                  icon=_icon("heart.png"))
    _add_item("[B]Continuar viendo[/B]",  _url(action="recent"),                     icon=_icon("history.png"))
    _add_item("[B]Buscar[/B]",            _url(action="search", src="uni"),          icon=_icon("search.png"))
    _add_item("[B]Últimos Episodios[/B]", _url(action="latest_episodes", src="uni"), icon=_icon("latest_eps.png"))
    _add_item("[B]Últimos Animes[/B]",    _url(action="latest_animes", src="uni"),   icon=_icon("latest_animes.png"))
    _add_item("[B]Todos los animes[/B]",  _url(action="browse", src="uni", kind="order", val="default", page=1),
              icon=_icon("catalog.png"))
    _add_item("[B]Por Letra[/B]",         _url(action="letter_menu", src="uni"), icon=_icon("order.png"))
    _add_item("[B]Por Género[/B]",        _url(action="genres_menu", src="uni"), icon=_icon("genres.png"))
    _add_item("[B]Por Tipo[/B]",          _url(action="types_menu", src="uni"),  icon=_icon("types.png"))
    _add_item("[B]Por Estado[/B]",        _url(action="status_menu", src="uni"), icon=_icon("status.png"))
    _add_item("[B]Por Año[/B]",           _url(action="year_menu", src="uni"),   icon=_icon("year.png"))
    _add_item("[B]Ordenar / Explorar[/B]", _url(action="order_menu", src="uni"), icon=_icon("order.png"))
    _end()


def _uni_search(query, browse=False):
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Búsqueda: {query}")
    _set_section_fanart()
    merged, failed = unified.uni_search(query)
    if not merged:
        _uni_empty(failed, f"Sin resultados para: {query}", redirect=not browse)
        return
    _uni_notice(failed)
    _add_anime_list(merged, "uni", enrich_network=False)
    _end(content_type="tvshows", update_listing=not browse)


def _uni_latest_animes():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Últimos Animes")
    _set_section_fanart()
    merged, failed = unified.uni_latest_animes()
    if not merged:
        _uni_empty(failed)
        return
    _uni_notice(failed)
    _add_anime_list(merged, "uni", enrich_network=False)
    _end(content_type="tvshows")


def _uni_latest_episodes():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Últimos Episodios")
    _set_section_fanart()
    merged, failed = unified.uni_latest_episodes()
    if not merged:
        _uni_empty(failed)
        return
    _uni_notice(failed)
    seen = {}
    for ep in merged:
        anime_name = _anime_title_from_ep(ep["title"])
        if anime_name not in seen:
            seen[anime_name] = anilist.enrich(anime_name) if _ANILIST_ON else {}
        rich   = seen[anime_name]
        fanart = rich.get("fanart", "") or _addon_fanart()
        plot   = rich.get("plot", "") or rich.get("plot_en", "")
        thumb  = ep.get("thumbnail", "")
        eps_token = unified.encode_sources(ep["urls"])

        li = xbmcgui.ListItem(label=f"[B]{ep['title']}[/B]")
        art = {"thumb": thumb, "poster": thumb, "icon": _icon("play.png")}
        if fanart:
            art["fanart"] = fanart
        li.setArt(art)
        li.setInfo("video", {
            "title":       ep["title"],
            "tvshowtitle": anime_name,
            "plot":        plot,
            "mediatype":   "episode",
        })
        li.addContextMenuItems([
            ("[B]Descargar (elegir servidor)[/B]",
             f"RunPlugin({_url(action='servers', src='uni', eps=eps_token, title=ep['title'], mode='download')})"),
            *_topzilla_ctx(anime_name),
            *_topzilla_add_ctx(anime_name, thumb, plot, rich.get("year", 0)),
        ])
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            _url(action="servers", src="uni", eps=eps_token, title=ep["title"]),
            li, isFolder=True,
        )
    _end(content_type="episodes")


def _uni_browse(kind, val, page_token):
    page_map = unified.decode_page_map(page_token)
    # "Por Letra" escanea muchas páginas (lento) y corre en este hilo (ver uni_browse),
    # así que se anima la barra con progreso real por ronda.
    progress, on_prog = None, None
    if kind == "letter":
        label = val.upper() if val != "#" else "#"
        progress = xbmcgui.DialogProgressBG()
        progress.create("Buscando animes", f"Letra {label}…")
        on_prog = lambda done, total: progress.update(
            int(done * 100 / total), "Buscando animes", f"Letra {label} — {done}/{total}")
    try:
        merged, next_map, failed = unified.uni_browse(kind, val, page_map, on_progress=on_prog)
    finally:
        if progress:
            progress.close()

    cat = {"genre": f"Género: {val}", "type": f"Tipo: {dict(TYPES).get(val, val)}",
           "status": f"Estado: {dict(STATUS).get(val, val)}", "year": f"Año: {val}",
           "order": f"Catálogo: {dict(ORDERS).get(val, val)}",
           "letter": f"Letra: {val.upper() if val != '#' else '#'}"}.get(kind, "Catálogo")
    xbmcplugin.setPluginCategory(ADDON_HANDLE, cat)
    _set_section_fanart()

    if not merged:
        _uni_empty(failed)
        return
    _uni_notice(failed)
    _add_anime_list(merged, "uni", enrich_network=False)
    if next_map:
        _add_item(
            "[B][COLOR gold]>> Página siguiente[/COLOR][/B]",
            _url(action="browse", src="uni", kind=kind, val=val,
                 page=unified.encode_sources(next_map)),
            icon=_icon("forward.png"),
        )
    _end(content_type="tvshows", cache=True)


def _uni_episodes(srcs_token, page):
    sources = unified.decode_sources(srcs_token)
    if not sources:
        xbmcgui.Dialog().ok(_UNI_NAME, "Enlace no disponible o caducado.")
        _end(succeeded=False)
        return

    cached = _ep_cache_get("uni", srcs_token)
    if cached:
        info, all_eps = cached.get("info", {}), cached.get("episodes", [])
    else:
        info, all_eps, _ = unified.uni_anime_bundle(sources)
        if all_eps:
            _ep_cache_set("uni", srcs_token, {"info": info, "episodes": all_eps})
    title    = info.get("title") or "Anime"
    poster   = info.get("poster", "")
    synopsis = info.get("synopsis", "")
    xbmcplugin.setPluginCategory(ADDON_HANDLE, title)

    if not all_eps:
        xbmcgui.Dialog().ok(_UNI_NAME,
                            "No se encontraron episodios.\n"
                            "Puede ser un problema de red o que el anime no esté disponible.")
        _end(succeeded=False)
        return

    rich   = (anilist.enrich(title, synopsis, poster) if _ANILIST_ON else {}) if page == 0 else {}
    fanart = rich.get("fanart", "") or _addon_fanart()
    poster = rich.get("poster", "") or poster
    plot   = rich.get("plot", "") or synopsis
    score  = rich.get("score", 0)
    genres = rich.get("genres", [])

    if page == 0 and all_eps:
        _push_recent("uni", srcs_token, title, poster)
        if _UPNEXT_ON:
            _store_playlist([
                {"n": str(e["number"]),
                 "t": f"{title} — {e['title']}",
                 "u": _url(action="smart_play", src="uni",
                           eps=unified.encode_sources(e["urls"]),
                           title=f"{title} — {e['title']}")}
                for e in all_eps])

    if _EPISODES_NEWEST_FIRST:
        all_eps = list(reversed(all_eps))

    _set_section_fanart(fanart)

    total    = len(all_eps)
    start    = page * EPISODES_PER_PAGE
    end      = start + EPISODES_PER_PAGE
    page_eps = all_eps[start:end]

    if page > 0:
        if _EPISODES_NEWEST_FIRST:
            ps = all_eps[(page - 1) * EPISODES_PER_PAGE : page * EPISODES_PER_PAGE]
            prev_lbl = (f"[B][COLOR cyan]<< Episodios {ps[-1].get('number','?')}–{ps[0].get('number','?')}[/COLOR][/B]"
                        if ps else "[B][COLOR cyan]<< Episodios anteriores[/COLOR][/B]")
        else:
            prev_lbl = f"[B][COLOR cyan]<< Episodios {(page-1)*EPISODES_PER_PAGE+1}–{page*EPISODES_PER_PAGE}[/COLOR][/B]"
        _add_item(prev_lbl, _url(action="episodes", src="uni", srcs=srcs_token, page=page - 1), icon=_icon("back.png"))

    for ep in page_eps:
        ep_title  = f"{title} — {ep['title']}"
        eps_token = unified.encode_sources(ep["urls"])
        li = xbmcgui.ListItem(label=f"[B]{ep['title']}[/B]")
        art = {"thumb": poster, "poster": poster}
        if fanart:
            art["fanart"] = fanart
        li.setArt(art)
        li.setInfo("video", {
            "title":       ep_title,
            "plot":        plot,
            "tvshowtitle": title,
            "mediatype":   "episode",
            "episode":     int(float(ep.get("number", 0) or 0)),
            "season":      1,
            "year":        rich.get("year", 0),
            "rating":      score / 10.0 if score else 0,
            "genre":       ", ".join(genres[:4]) if genres else "",
        })
        li.addContextMenuItems([
            ("[B]Descargar (elegir servidor)[/B]",
             f"RunPlugin({_url(action='servers', src='uni', eps=eps_token, title=ep_title, mode='download')})"),
            *_topzilla_ctx(title),
            *_topzilla_add_ctx(title, poster, plot, rich.get("year", 0)),
        ])
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            _url(action="servers", src="uni", eps=eps_token, title=ep_title),
            li, isFolder=True,
        )

    if end < total:
        if _EPISODES_NEWEST_FIRST:
            ns = all_eps[end : min(end + EPISODES_PER_PAGE, total)]
            next_lbl = f"[B][COLOR gold]>> Episodios {ns[-1].get('number','?')}–{ns[0].get('number','?')}[/COLOR][/B]"
        else:
            next_lbl = f"[B][COLOR gold]>> Episodios {end+1}–{min(end+EPISODES_PER_PAGE,total)}[/COLOR][/B]"
        _add_item(next_lbl, _url(action="episodes", src="uni", srcs=srcs_token, page=page + 1), icon=_icon("forward.png"))
    _end(content_type="episodes", cache=True)


def _uni_servers(eps_token, title, mode="play"):
    eps_map = unified.decode_sources(eps_token)
    if not eps_map:
        xbmcgui.Dialog().ok(_UNI_NAME, "Enlace no disponible o caducado.")
        if mode != "download":
            _end(succeeded=False)
        return
    servers, failed = unified.uni_servers(eps_map)
    if not servers and _uni_all_failed(failed):
        xbmcgui.Dialog().ok(_UNI_NAME, "No se pudo conectar con ninguna fuente.\nRevisa tu conexión.")
        if mode != "download":
            _end(succeeded=False)
        return
    play_all = _url(action="smart_play", src="uni", eps=eps_token, title=title)
    verify   = _url(action="filter_servers", src="uni", eps=eps_token, title=title)
    _render_servers(servers, title, mode, _UNI_NAME, play_all, verify)


# DESCARGAS

def _downloads_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Descargas")
    _set_section_fanart()

    current = downloader.get_download_dir(ask_if_empty=False)
    if current:
        folder_label = f"[B][COLOR gray]Carpeta: {current}[/COLOR][/B]"
    else:
        folder_label = "[B][COLOR orange]Carpeta de descargas: no configurada[/COLOR][/B]"

    _add_item(
        folder_label,
        _url(action="set_download_dir"),
        icon=_icon("order.png"),
        is_folder=False,
    )

    files = downloader.list_downloads()
    if not files:
        _add_item(
            "[B][COLOR gray]No hay descargas todavía.[/COLOR][/B]",
            _url(action="downloads"),
            icon=_icon("downloads.png"),
            is_folder=False,
        )
    else:
        for f in files:
            _add_item(
                f"[B]{f['name']}[/B]",
                f["path"],
                icon=_icon("play.png"),
                info={"title": f["name"], "mediatype": "video"},
                is_folder=False,
                is_playable=True,
            )
    _end(content_type="videos")


# JIKAN / MYANIMELIST: estadísticas, reseñas, relacionados, recomendados

def _get_mal_id(title):
    """MAL ID del anime desde la caché de AniList (enrich on-demand si falta). 0 si no hay.
    Requiere _ANILIST_ON: las features de Jikan dependen de este id."""
    if not _ANILIST_ON or not title:
        return 0
    clean = _anilist_title(title)
    rich  = anilist.get_cached(clean) or anilist.enrich(clean)
    return rich.get("idMal") or 0


def _add_search_item(name, label, thumb="", plot=""):
    """Item que al pulsarlo busca 'name' en el catálogo por defecto. browse=1 hace que
    Atrás vuelva a esta lista (relacionados/recomendados/calendario), donde el contenido
    viene identificado por título de MAL/AniList y hay que resolverlo en los scrapers."""
    _add_item(label, _url(action="search", src=_DEFAULT_SRC, query=name, browse=1),
              thumbnail=thumb,
              info={"title": name, "plot": plot, "mediatype": "tvshow"})


def _anime_stats(title):
    mal_id = _get_mal_id(title)
    if not mal_id:
        xbmcgui.Dialog().notification("Estadísticas", "No hay datos de MAL para este anime.",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        return
    stats = jikan.get_statistics(mal_id)
    if not stats:
        xbmcgui.Dialog().notification("Estadísticas", "No se pudieron obtener estadísticas.",
                                      xbmcgui.NOTIFICATION_WARNING, 2500)
        return
    total = stats.get("total", 0) or 0
    lines = [f"Total usuarios: {total:,}"] if total else []
    for k, label in [("watching", "Viendo"), ("completed", "Completado"),
                     ("on_hold", "En espera"), ("dropped", "Abandonado"),
                     ("plan_to_watch", "Planificado")]:
        n = stats.get(k, 0) or 0
        if n:
            pct = (n / total * 100) if total else 0
            lines.append(f"  {label}: {n:,}  ({pct:.1f}%)")
    scores = stats.get("scores") or []
    if scores:
        lines += ["", "Distribución de puntuaciones:"]
        max_votes = max((s.get("votes", 0) for s in scores), default=0) or 1
        for s in scores:
            filled = int(s.get("votes", 0) / max_votes * 20)
            bar = "#" * filled + "." * (20 - filled)
            lines.append(f"  {s.get('score', 0):2d} |{bar}| "
                         f"{s.get('percentage', 0):.1f}%  ({s.get('votes', 0):,})")
    xbmcgui.Dialog().textviewer(f"Estadísticas — {title}", "\n".join(lines) or "Sin datos.")


def _anime_reviews(title):
    # Diálogo puro (select → textviewer → volver al select). Invocado por RunPlugin:
    # no construye directorio, no toca el historial ni arriesga "playback failed".
    mal_id = _get_mal_id(title)
    if not mal_id:
        xbmcgui.Dialog().notification("Reseñas", "No hay datos de MAL para este anime.",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        return
    page = 1
    sel  = 0    # recuerda la última reseña abierta para reabrir el select sobre ella
    while True:
        items, pagination = jikan.get_reviews(mal_id, page)
        if not items:
            xbmcgui.Dialog().notification("Reseñas", "No hay reseñas disponibles.",
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            return
        labels = []
        for rev in items:
            user  = (rev.get("user") or {}).get("username", "?")
            score = rev.get("score", 0)
            tags  = "  ".join(f"[{t}]" for t in (rev.get("tags") or [])[:2])
            labels.append(f"{user}   {score}/10   {tags}".rstrip())
        more = bool(pagination.get("has_next_page"))
        if more:
            labels.append("[ Más reseñas… ]")
        idx = xbmcgui.Dialog().select(f"Reseñas — {title} (pág. {page})", labels, preselect=sel)
        if idx < 0:
            return
        if more and idx == len(items):
            page += 1
            sel  = 0
            continue
        sel   = idx
        rev   = items[idx]
        user  = (rev.get("user") or {}).get("username", "?")
        score = rev.get("score", 0)
        text  = rev.get("review") or "Sin texto."
        xbmcgui.Dialog().textviewer(f"{user} ({score}/10) — {title}", text)


_REL_ES = {
    "Prequel": "Precuela", "Sequel": "Secuela", "Side Story": "Historia paralela",
    "Spin-off": "Spin-off", "Alternative version": "Versión alternativa",
    "Alternative setting": "Escenario alternativo", "Summary": "Resumen",
    "Full story": "Historia completa", "Parent story": "Historia principal",
    "Other": "Otro", "Character": "Personaje", "Adaptation": "Adaptación",
}


def _anime_related(title):
    mal_id = _get_mal_id(title)
    if not mal_id:
        xbmcgui.Dialog().notification("Relacionados", "No hay datos de MAL para este anime.",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        _end(succeeded=False)
        return
    items = [
        (_REL_ES.get(grp.get("relation", ""), grp.get("relation", "")), e.get("name", ""))
        for grp in jikan.get_relations(mal_id)
        for e in (grp.get("entry") or [])
        if e.get("type") == "anime" and e.get("name")
    ]
    if not items:
        xbmcgui.Dialog().notification("Relacionados", "Sin anime relacionados.",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        _end(succeeded=False)
        return
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Relacionados — {title}")
    _set_section_fanart()
    for rel_label, name in items:
        _add_search_item(name, f"[B]{name}[/B]  [COLOR gray]({rel_label})[/COLOR]",
                         plot=f"{rel_label} de {title}")
    _end(content_type="tvshows")


def _anime_recommended(title):
    mal_id = _get_mal_id(title)
    if not mal_id:
        xbmcgui.Dialog().notification("Recomendados", "No hay datos de MAL para este anime.",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        _end(succeeded=False)
        return
    recs = jikan.get_recommendations(mal_id)
    if not recs:
        xbmcgui.Dialog().notification("Recomendados", "Sin recomendaciones.",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        _end(succeeded=False)
        return
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Recomendados — {title}")
    _set_section_fanart()
    for rec in recs[:30]:                       # Jikan ya ordena por relevancia
        entry = rec.get("entry") or {}
        name  = entry.get("title", "")
        if not name:
            continue
        thumb = ((entry.get("images") or {}).get("jpg") or {}).get("image_url", "")
        votes = rec.get("votes", 0)
        _add_search_item(name, f"[B]{name}[/B]", thumb=thumb,
                         plot=f"Recomendado por {votes} usuarios." if votes else "")
    _end(content_type="tvshows")


# CALENDARIO DE EMISIÓN

_DAYS = [("monday", "Lunes"), ("tuesday", "Martes"), ("wednesday", "Miércoles"),
         ("thursday", "Jueves"), ("friday", "Viernes"), ("saturday", "Sábado"),
         ("sunday", "Domingo")]
_DAY_ES = dict(_DAYS)


def _airing_schedule():
    today   = datetime.now().weekday()          # 0 = lunes (hora local)
    ordered = _DAYS[today:] + _DAYS[:today]
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Emisión semanal")
    _set_section_fanart()
    for i, (day_en, day_es) in enumerate(ordered):
        label = f"[B]{day_es}[/B]" + ("  [COLOR lime](hoy)[/COLOR]" if i == 0 else "")
        _add_item(label, _url(action="airing_day", day=day_en), icon=_icon("latest_eps.png"))
    _end()


def _airing_day(day):
    day_es     = _DAY_ES.get(day, day)
    anime_list = jikan.get_schedule(day)
    if not anime_list:
        xbmcgui.Dialog().notification("Emisión semanal",
                                      f"Sin datos para {day_es}. Revisa la conexión.",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        _end(succeeded=False)
        return
    xbmcplugin.setPluginCategory(ADDON_HANDLE, f"Emisión — {day_es}")
    _set_section_fanart()
    for a in anime_list:
        name = a.get("title") or a.get("title_english") or ""
        if not name:
            continue
        thumb = ((a.get("images") or {}).get("jpg") or {}).get("image_url", "")
        parts = []
        t = (a.get("broadcast") or {}).get("time")
        if t:                 parts.append(f"Hora JP: {t}")
        if a.get("score"):    parts.append(f"MAL: {a['score']}")
        if a.get("episodes"): parts.append(f"Eps: {a['episodes']}")
        syn = a.get("synopsis") or ""
        if syn:               parts.append("\n" + (syn[:300] + "…" if len(syn) > 300 else syn))
        _add_search_item(name, f"[B]{name}[/B]", thumb=thumb, plot="\n".join(parts))
    _end(content_type="tvshows")


# ENRUTADOR

def _require_scrapers():
    """Asegura el módulo de scrapers antes de una acción de catálogo. True si disponible.
    Si falla (worker caído / sin red), avisa y cierra el directorio limpiamente."""
    if loader.get() is not None:
        return True
    # No abrimos busy dialog propio: xbmcgui.DialogBusy no existe en Kodi 21 y el
    # builtin busydialognocancel arrastra kodi/kodi#20297. Kodi ya muestra su spinner
    # nativo mientras el plugin puebla el directorio.
    if loader.ensure():
        return True
    xbmcgui.Dialog().notification(
        "Espanime", "No se pudo cargar el catálogo. Comprueba la conexión.",
        xbmcgui.NOTIFICATION_ERROR, 5000,
    )
    _end(succeeded=False)
    return False


def build_menu():
    if not _legal_gate():
        xbmcgui.Dialog().notification(
            "Espanime", "Debes aceptar el Aviso Legal para usar el addon.",
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        _end(succeeded=False)
        return

    params = _params()
    action = params.get("action", "main")
    src    = params.get("src", _DEFAULT_SRC)

    if action in _SCRAPER_ACTIONS and not _require_scrapers():
        return

    if action == "main":
        if _ANILIST_ON:
            anilist.purge_expired()  # limpia caché caducada, throttled a 1/día
        _main_menu()
    elif action == "home":
        _home(src)
    elif action == "search":
        _search(src, params.get("query"), params.get("browse") == "1")
    elif action == "latest_episodes":
        _latest_episodes(src)
    elif action == "latest_animes":
        _latest_animes(src)
    elif action == "genres_menu":
        _genres_menu(src)
    elif action == "types_menu":
        _types_menu(src)
    elif action == "status_menu":
        _status_menu(src)
    elif action == "year_menu":
        _year_menu(src)
    elif action == "order_menu":
        _order_menu(src)
    elif action == "letter_menu":
        _letter_menu(src)
    elif action == "browse":
        kind, val = params.get("kind", "order"), params.get("val", "default")
        if src == "uni":
            _uni_browse(kind, val, params.get("page", "1"))  # page = mapa JSON por fuente
        else:
            _browse(src, kind, val, _to_int(params.get("page"), 1))
    elif action == "episodes":
        if src == "uni":
            _uni_episodes(params.get("srcs", ""), _to_int(params.get("page"), 0))
        else:
            _episodes(src, params.get("anime_path", ""), _to_int(params.get("page"), 0))
    elif action == "servers":
        if src == "uni":
            _uni_servers(params.get("eps", ""), params.get("title", ""),
                         params.get("mode", "play"))
        else:
            _servers(src, params.get("ep_url", ""), params.get("title", ""),
                     params.get("mode", "play"))
    elif action == "play":
        _resolve_and_play(params.get("video_url", ""), params.get("title", ""),
                          params.get("server", ""))
    elif action == "smart_play":
        if src == "uni":
            eps_map = unified.decode_sources(params.get("eps", ""))
            servers = unified.uni_servers(eps_map)[0] if eps_map else []
            name = _UNI_NAME
        else:
            servers = _get_scraper(src).get_video_servers(params.get("ep_url", ""))
            name = _name(src)
        _, playable = _filter_and_sort_servers(servers)
        _smart_play(playable, name, params.get("title", ""))
    elif action == "filter_servers":
        _filter_servers(src, params.get("ep_url", ""), params.get("eps", ""),
                        params.get("title", ""))
    elif action == "download":
        downloader.download(params.get("video_url", ""), params.get("title", "anime"))
    elif action == "downloads":
        _downloads_menu()
    elif action == "set_download_dir":
        chosen = xbmcgui.Dialog().browse(3, "Selecciona carpeta de descargas", "files")
        if chosen:
            ADDON.setSetting("download_path", chosen)
            xbmcgui.Dialog().notification("Descargas",
                f"Carpeta configurada: {chosen}", xbmcgui.NOTIFICATION_INFO, 3000)
        _end(succeeded=False)
    elif action == "manage_fanart":
        _manage_fanart()
        _end(succeeded=False)
    elif action == "open_settings":
        ADDON.openSettings()
        _end(succeeded=False)
    elif action == "clear_cache":
        n = anilist.clear_cache() + jikan.clear_cache() + _ep_cache_clear()
        xbmcgui.Dialog().notification(
            "Espanime", f"Caché borrada: {n} archivo(s)",
            xbmcgui.NOTIFICATION_INFO, 3000)
    elif action == "clear_search_history":
        _save_json("search_history.json", [])
        xbmcgui.Dialog().notification(
            "Espanime", "Historial de búsqueda borrado",
            xbmcgui.NOTIFICATION_INFO, 2500)
    elif action == "clear_recent":
        _save_json("recently_viewed.json", [])
        xbmcgui.Dialog().notification(
            "Espanime", "Historial de reproducción borrado",
            xbmcgui.NOTIFICATION_INFO, 2500)
    elif action == "clear_server_stats":
        _save_json("server_stats.json", {})
        xbmcgui.Dialog().notification(
            "Espanime", "Estadísticas de servidores borradas",
            xbmcgui.NOTIFICATION_INFO, 2500)
    elif action == "anime_info":
        title = params.get("title", "")
        rich  = anilist.enrich(title) if _ANILIST_ON else {}
        score = rich.get("score", 0)
        year  = rich.get("year", 0)
        studio = rich.get("studio", "")
        status = _STATUS_ES.get(rich.get("status", ""), rich.get("status", ""))
        episodes = rich.get("episodes", 0)
        genres = ", ".join(rich.get("genres", [])[:6])
        plot   = rich.get("plot", "") or rich.get("plot_en", "")
        lines = []
        if year:    lines.append(f"Año: {year}")
        if studio:  lines.append(f"Estudio: {studio}")
        if score:   lines.append(f"Puntuación: {score / 10:.1f} / 10")
        if episodes: lines.append(f"Episodios: {episodes}")
        if status:  lines.append(f"Estado: {status}")
        if genres:  lines.append(f"Géneros: {genres}")
        if plot:    lines.append(f"\n{plot}")
        body = "  |  ".join(lines[:5])
        if len(lines) > 5:
            body += "\n" + "\n".join(lines[5:])
        if body:
            xbmcgui.Dialog().textviewer(title or "Información", body)
        else:
            xbmcgui.Dialog().notification("Info", "No hay datos de AniList para este anime.",
                                          xbmcgui.NOTIFICATION_INFO, 2500)
        _end(succeeded=False)
    elif action == "anime_stats":          # RunPlugin → diálogo
        _anime_stats(params.get("title", ""))
    elif action == "anime_reviews":        # RunPlugin → diálogo (select/textviewer)
        _anime_reviews(params.get("title", ""))
    elif action == "anime_related":        # Container.Update → directorio
        _anime_related(params.get("title", ""))
    elif action == "anime_recommended":    # Container.Update → directorio
        _anime_recommended(params.get("title", ""))
    elif action == "airing_schedule":
        _airing_schedule()
    elif action == "airing_day":
        _airing_day(params.get("day", "monday"))
    elif action == "toggle_fav":
        favs  = _load_json("favorites.json")
        key   = _fav_key(params.get("src", ""), params.get("id", ""))
        if key in favs:
            del favs[key]
            msg = "Eliminado de favoritos"
        else:
            favs[key] = {
                "title":     params.get("title", ""),
                "thumbnail": params.get("thumbnail", ""),
                "src":       params.get("src", ""),
                "id":        params.get("id", ""),
                "srcs":      params.get("srcs"),
            }
            msg = "Añadido a favoritos"
        _save_json("favorites.json", favs)
        xbmcgui.Dialog().notification("Favoritos", msg, xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
        _end(succeeded=False)
    elif action == "favorites":
        favs = _load_json("favorites.json")
        if not favs:
            xbmcgui.Dialog().notification("Favoritos", "No tienes favoritos aún.",
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            _end(succeeded=False)
            return
        xbmcplugin.setPluginCategory(ADDON_HANDLE, "Mis Favoritos")
        _set_section_fanart()
        for r in favs.values():
            rich   = anilist.get_cached(r["title"]) if _ANILIST_ON else {}
            fanart = rich.get("fanart", "") or _addon_fanart()
            li = xbmcgui.ListItem(label=f"[B]{r['title']}[/B]")
            art = {"thumb": r["thumbnail"], "poster": r["thumbnail"]}
            if fanart:
                art["fanart"] = fanart
            li.setArt(art)
            plot = rich.get("plot") or rich.get("plot_en") or ""
            li.setInfo("video", {"title": r["title"], "mediatype": "tvshow",
                                  "year": rich.get("year", 0), "plot": plot})
            fav_url = _url(action="toggle_fav", src=r["src"], id=r.get("id", ""),
                           title=r["title"], thumbnail=r.get("thumbnail", ""))
            li.addContextMenuItems([("[B]Quitar de favoritos[/B]", f"RunPlugin({fav_url})")])
            if r.get("src") == "uni":
                target = _url(action="episodes", src="uni", srcs=r.get("id", ""), page=0)
            else:
                target = _url(action="episodes", src=r["src"],
                              anime_path=r.get("id", ""), page=0)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, target, li, isFolder=True)
        _end(content_type="tvshows")
    elif action == "recent":
        items = _load_recent()
        if not items:
            xbmcgui.Dialog().notification("Continuar viendo", "Aún no has visto nada.",
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            _end(succeeded=False)
            return
        xbmcplugin.setPluginCategory(ADDON_HANDLE, "Continuar viendo")
        _set_section_fanart()
        for r in items:
            rich   = anilist.get_cached(r["title"]) if _ANILIST_ON else {}
            fanart = rich.get("fanart", "") or _addon_fanart()
            label = f"[B]{r['title']}[/B]"
            if r.get("last_ep"):
                label = f"[B]{r['title']}[/B]  [COLOR gray](Ep. {r['last_ep']})[/COLOR]"
            li = xbmcgui.ListItem(label=label)
            art = {"thumb": r.get("thumbnail", ""), "poster": r.get("thumbnail", "")}
            if fanart:
                art["fanart"] = fanart
            li.setArt(art)
            plot = rich.get("plot") or rich.get("plot_en") or ""
            li.setInfo("video", {"title": r["title"], "mediatype": "tvshow",
                                  "year": rich.get("year", 0), "plot": plot})
            if r.get("srcs"):
                target = _url(action="episodes", src="uni", srcs=r["srcs"], page=0)
            else:
                target = _url(action="episodes", src=r["src"],
                              anime_path=r.get("id", ""), page=0)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, target, li, isFolder=True)
        _end(content_type="tvshows")
    # Compatibilidad con URLs antiguas
    elif action in ("select_server", "browse_all", "browse_genre"):
        _servers(src, params.get("ep_url", ""), params.get("title", ""))
    else:
        xbmc.log(f"[Anime] Acción desconocida: {action}", xbmc.LOGWARNING)
        _end(succeeded=False)
