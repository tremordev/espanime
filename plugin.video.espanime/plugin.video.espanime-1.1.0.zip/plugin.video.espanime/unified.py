# Autor: tremordev
# Motor del Modo Unificado: fusiona y deduplica resultados de todas las fuentes.
# Módulo puro (solo xbmc.log). Una tarea por FUENTE en paralelo. Cada worker posee
# un scraper en exclusiva, así no hay concurrencia intra-módulo. Ante fallo parcial
# (una fuente caída/lenta) sigue mostrándose la otra.

import json
import re
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcaddon

import loader

_CLASS_NAMES = {"aflv": "AnimeFLVScraper", "tio": "TioAnimeScraper",
                "lat":  "LatanimeScraper",  "mono": "MonosChinosScraper"}
_ORDER   = ("aflv", "tio", "lat", "mono")   # aflv primero: título ES + synopsis real
_LABELS  = {"aflv": "S1", "tio": "S2", "lat": "S3", "mono": "S4"}


def _classes():
    mod = loader.get()
    if mod is None:
        raise RuntimeError('[EspAnime] unified: módulo de scrapers no disponible')
    return {src: getattr(mod, name) for src, name in _CLASS_NAMES.items()}


def _timeout():
    """Timeout base configurable por el usuario (settings). Por defecto 12s."""
    try:
        return max(5, int(xbmcaddon.Addon().getSetting("timeout_seconds")))
    except (TypeError, ValueError):
        return 12

# AnimeFLV usa slugs (tv/movie/ova/special); TioAnime usa 0/1/2/3. Género y
# estado son idénticos entre ambos sitios (verificado), así que no se mapean.
TYPE_MAP = {"tv": "0", "movie": "1", "ova": "2", "special": "3"}

_SEASON_WORDS = {"season", "temporada", "parte", "part", "cour"}
_EP_WORDS     = {"episodio", "capitulo", "cap", "ep", "episode"}


# PARALELISMO

def run_parallel(tasks, timeout=None):
    """
    Ejecuta {src: callable} en paralelo. Devuelve (results, failed):
      results[src] = valor o None si la fuente falló/expiró.
      failed       = set de fuentes con excepción o timeout.
    Latencia acotada al global `timeout` (deadline compartido), no a la suma.
    timeout=None usa el valor configurado por el usuario (_timeout()).
    """
    if timeout is None:
        timeout = _timeout()
    results, failed = {}, set()
    if not tasks:
        return results, failed
    ex = ThreadPoolExecutor(max_workers=len(tasks))
    try:
        futures = {src: ex.submit(fn) for src, fn in tasks.items()}
        deadline = time.monotonic() + timeout
        for src, fut in futures.items():
            try:
                results[src] = fut.result(timeout=max(0.0, deadline - time.monotonic()))
            except Exception as exc:
                xbmc.log(f"[Unified] fuente {src} falló/expiró: {exc}", xbmc.LOGWARNING)
                results[src] = None
                failed.add(src)
    finally:
        # wait=False: un worker colgado en su socket drena en background sin
        # bloquear endOfDirectory (su propio timeout lo cierra).
        ex.shutdown(wait=False)
    return results, failed


# NORMALIZACIÓN (claves de dedup)

def _strip_accents(text):
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))


def normalize_title(title, drop_words=None):
    """
    Clave de dedup. Colapsa marcadores de temporada (Season/Temporada/S2/2nd
    Season) a número canónico, pero NUNCA toca números embebidos (Mob Psycho
    100, 86, 91 Days). `drop_words` opcional elimina tokens extra (p.ej. episodio).
    """
    if not title:
        return ""
    drop = drop_words or set()
    t = _strip_accents(title).lower()
    t = re.sub(r"[\(\[\{][^\)\]\}]*[\)\]\}]", " ", t)   # quita (TV), [BD]…
    t = re.sub(r"[^a-z0-9]+", " ", t)
    tokens = t.split()
    out, i = [], 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in drop:
            i += 1
            continue
        if tok in _SEASON_WORDS:                        # "season"/"temporada" + nº
            if i + 1 < len(tokens) and tokens[i + 1].isdigit():
                out.append(tokens[i + 1]); i += 2; continue
            i += 1; continue
        m = re.fullmatch(r"(\d+)(?:nd|rd|st|th)", tok)  # "2nd season"
        if m and i + 1 < len(tokens) and tokens[i + 1] in _SEASON_WORDS:
            out.append(m.group(1)); i += 2; continue
        m = re.fullmatch(r"[st](\d{1,2})", tok)          # "s2"/"t2" pegados
        if m:
            out.append(m.group(1)); i += 1; continue
        out.append(tok); i += 1
    key = " ".join(out).strip()
    return key or title.strip().lower()


def _norm_ep(title):
    return normalize_title(title, drop_words=_EP_WORDS)


# HELPERS

def _to_num(n):
    try:
        return float(n)
    except (TypeError, ValueError):
        return None


def _canon_num(n):
    """Clave canónica de número de episodio: 8 / 8.0 / '8' → '8'; 7.5 → '7.5'."""
    f = _to_num(n)
    if f is None:
        return str(n)
    return str(int(f)) if f.is_integer() else str(f)


def _host_of(url):
    m = re.search(r"https?://([^/|]+)", url or "")
    return m.group(1).lower() if m else (url or "")


def _norm_url_key(url):
    """
    Clave de dedup por URL normalizada completa (sin esquema, sin cabeceras |,
    sin barra final, minúsculas). Conserva el query: distingue dos vídeos del
    mismo host (p.ej. embed.php?v=A vs ?v=B) pero unifica enlaces idénticos
    que vienen con nombres de servidor distintos (Yu / YourUpload).
    """
    u = (url or "").split("|", 1)[0]
    u = re.sub(r"^https?://", "", u, flags=re.IGNORECASE)
    return u.rstrip("/").lower()


# MERGES

def merge_anime_lists(per_source):
    """per_source = [(src, [anime]), ...] → items {title, thumbnail, synopsis, sources:{src:id}}."""
    merged, order = {}, []
    for src, animes in per_source:
        for a in animes or []:
            title, aid = a.get("title", ""), a.get("id", "")
            if not title or not aid:
                continue
            key = normalize_title(title)
            if key not in merged:
                merged[key] = {
                    "title":     title,
                    "thumbnail": a.get("thumbnail", ""),
                    "synopsis":  a.get("synopsis", ""),
                    "sources":   {src: aid},
                }
                order.append(key)
            else:
                rec = merged[key]
                rec["sources"].setdefault(src, aid)
                if not rec["thumbnail"]:
                    rec["thumbnail"] = a.get("thumbnail", "")
                if not rec["synopsis"]:
                    rec["synopsis"] = a.get("synopsis", "")
    return [merged[k] for k in order]


def merge_latest_episodes(per_source):
    """per_source = [(src, [ep{title,url,thumbnail}])] → items {title, thumbnail, urls:{src:url}}."""
    merged, order = {}, []
    for src, eps in per_source:
        for e in eps or []:
            title, url = e.get("title", ""), e.get("url", "")
            if not title or not url:
                continue
            key = _norm_ep(title)
            if key not in merged:
                merged[key] = {"title": title, "thumbnail": e.get("thumbnail", ""), "urls": {src: url}}
                order.append(key)
            else:
                merged[key]["urls"].setdefault(src, url)
                if not merged[key]["thumbnail"]:
                    merged[key]["thumbnail"] = e.get("thumbnail", "")
    return [merged[k] for k in order]


def merge_episode_lists(per_source):
    """
    per_source = [(src, [ep{number,title,url}])] → items {number, title, urls:{src:url}}.

    Fusiona por número: cada episodio recoge las URLs de las fuentes que lo tengan,
    de modo que al reproducir se ofrecen servidores de ambas. No se intenta adivinar
    desfases de cour por diferencia de conteo: el caso habitual de conteos distintos
    es que una fuente vaya por detrás emitiendo (ep N = ep N igualmente), y un heurístico
    de máximo descartaría episodios perfectamente alineados. setdefault evita que un
    número repetido dentro de una misma fuente pise la primera URL.
    """
    bynum, order = {}, []
    for src, eps in per_source:
        for e in eps or []:
            k = _canon_num(e["number"])
            if k not in bynum:
                bynum[k] = {"number": e["number"], "title": e["title"],
                            "urls": {}, "_sort": _to_num(e["number"])}
                order.append(k)
            bynum[k]["urls"].setdefault(src, e["url"])
    out = sorted((bynum[k] for k in order),
                 key=lambda x: (x["_sort"] is None, x["_sort"] or 0))
    for x in out:
        x.pop("_sort", None)
    return out


def merge_server_lists(per_source):
    """
    per_source = [(label, [server{server,url,language,direct}])] → lista deduplicada
    por URL normalizada; preferimos direct en duplicado; etiqueta origen en s['origin'].
    """
    pos = {}
    out = []
    for label, servers in per_source:
        for s in servers or []:
            url = s.get("url", "")
            if not url:
                continue
            key = _norm_url_key(url)
            if key in pos:
                idx = pos[key]
                if s.get("direct") and not out[idx].get("direct"):
                    s2 = dict(s); s2["origin"] = label
                    out[idx] = s2
                continue
            s2 = dict(s); s2["origin"] = label
            pos[key] = len(out)
            out.append(s2)
    return out


def merge_genre_lists(per_source):
    """Géneros (slug,name); slugs idénticos entre sitios → unión por slug."""
    merged, order = {}, []
    for genres in per_source:
        for gid, name in genres or []:
            if gid not in merged:
                merged[gid] = name
                order.append(gid)
    return [(gid, merged[gid]) for gid in order]


def _combine_info(infos):
    """Combina get_anime_info de varias fuentes: prefiere aflv, synopsis no vacía, union géneros."""
    out = {"title": "", "poster": "", "synopsis": "", "genres": []}
    for _, info in infos:
        if not info:
            continue
        if not out["title"] and info.get("title"):
            out["title"] = info["title"]
        if not out["poster"] and info.get("poster"):
            out["poster"] = info["poster"]
        if not out["synopsis"] and info.get("synopsis"):
            out["synopsis"] = info["synopsis"]
        for g in info.get("genres", []) or []:
            if g not in out["genres"]:
                out["genres"].append(g)
    return out


# CODIFICACIÓN URL (mapas {src: valor})

def encode_sources(mapping):
    return json.dumps(mapping, separators=(",", ":"))


def decode_sources(token):
    if not token:
        return {}
    try:
        d = json.loads(token)
    except json.JSONDecodeError:
        return {}
    if not isinstance(d, dict):
        return {}
    return {k: v for k, v in d.items() if k in _CLASS_NAMES and isinstance(v, str) and v}


def decode_page_map(token):
    """Mapa de paginación {src: int|null}. Tolerante; vacío → primera página de ambas."""
    if not token:
        return {s: 1 for s in _CLASS_NAMES}
    try:
        d = json.loads(token)
    except json.JSONDecodeError:
        return {s: 1 for s in _CLASS_NAMES}
    if not isinstance(d, dict):
        return {s: 1 for s in _CLASS_NAMES}
    out = {}
    for k, v in d.items():
        if k in _CLASS_NAMES and isinstance(v, int):
            out[k] = v
    return out or {s: 1 for s in _CLASS_NAMES}


# OPERACIONES DE ALTO NIVEL

def uni_search(query):
    tasks = {s: (lambda c=c: c().search(query)) for s, c in _classes().items()}
    results, failed = run_parallel(tasks)
    merged = merge_anime_lists([(s, results.get(s) or []) for s in _ORDER])
    return merged, failed


def uni_latest_animes():
    tasks = {s: (lambda c=c: c().get_latest_animes()) for s, c in _classes().items()}
    results, failed = run_parallel(tasks)
    return merge_anime_lists([(s, results.get(s) or []) for s in _ORDER]), failed


def uni_latest_episodes():
    tasks = {s: (lambda c=c: c().get_latest_episodes()) for s, c in _classes().items()}
    results, failed = run_parallel(tasks)
    return merge_latest_episodes([(s, results.get(s) or []) for s in _ORDER]), failed


def uni_genres():
    tasks = {s: (lambda c=c: c().get_genres()) for s, c in _classes().items()}
    results, failed = run_parallel(tasks)
    return merge_genre_lists([results.get(s) or [] for s in _ORDER]), failed


def _browse_call(src, scraper, kind, val, page):
    if kind == "genre":
        return scraper.browse_by_genre(val, page)
    if kind == "type":
        v = val if src == "aflv" else TYPE_MAP.get(val)
        if not v:
            return [], None
        return scraper.browse_by_type(v, page)
    if kind == "status":
        return scraper.browse_by_status(val, page)
    if kind == "year":
        return scraper.browse_by_year(val, page)
    if kind == "letter":
        return scraper.browse_by_letter(val, page)
    return scraper.browse_all(page, order=val)


def uni_browse(kind, val, page_map, on_progress=None):
    """Devuelve (animes_merged, next_page_map|None, failed).

    'letter' es un caso aparte: solo AnimeFLV tiene orden alfabético y su escaneo es
    largo (decenas de páginas). Se ejecuta DIRECTO (no en run_parallel) para no chocar
    con el deadline corto ni dejar un ThreadPoolExecutor anidado huérfano en un worker
    abandonado; corre en este hilo, así que admite barra de progreso (on_progress)."""
    if kind == "letter":
        pg = page_map.get("aflv") or 1
        animes, nxt = _classes()["aflv"]().browse_by_letter(val, pg, on_progress=on_progress)
        return merge_anime_lists([("aflv", animes)]), ({"aflv": nxt} if nxt else None), set()

    tasks = {}
    for src, cls in _classes().items():
        pg = page_map.get(src)
        if pg is None:
            continue
        tasks[src] = (lambda s=src, c=cls, p=pg: _browse_call(s, c(), kind, val, p))
    results, failed = run_parallel(tasks)

    per_source, next_map = [], {}
    for src in _ORDER:
        res = results.get(src)
        if not res:
            continue
        animes, nxt = res
        per_source.append((src, animes))
        if nxt:
            next_map[src] = nxt
    merged = merge_anime_lists(per_source)
    return merged, (next_map or None), failed


def uni_anime_bundle(sources):
    """
    sources = {src: anime_id}. Un worker por fuente que hace get_anime_info +
    get_episodes SECUENCIAL (sin concurrencia intra-módulo). Devuelve
    (info_combinada, episodios_merged, failed).
    """
    def bundle(cls, aid):
        sc = cls()
        return sc.get_anime_info(aid), sc.get_episodes(aid)

    classes = _classes()
    tasks = {s: (lambda c=classes[s], a=aid: bundle(c, a))
             for s, aid in sources.items() if s in classes}
    # Holgura sobre el timeout base: MonosChinos pagina caplist (N POST al mismo host)
    # con throttle; en series largas necesita margen para no truncar episodios.
    results, failed = run_parallel(tasks, timeout=_timeout() + 6)

    infos, per_eps = [], []
    for src in _ORDER:
        res = results.get(src)
        if not res:
            continue
        info, eps = res
        if info:
            infos.append((src, info))
        if eps:
            per_eps.append((src, eps))
    return _combine_info(infos), merge_episode_lists(per_eps), failed


def uni_servers(eps_map):
    """eps_map = {src: episode_url} → servidores combinados de ambas fuentes."""
    classes = _classes()
    tasks = {s: (lambda s=s, u=url: classes[s]().get_video_servers(u))
             for s, url in eps_map.items() if s in classes}
    results, failed = run_parallel(tasks, timeout=_timeout() + 6)   # holgado: incluye /check gocdn
    per_source = []
    for src in _ORDER:
        servers = results.get(src)
        if servers:
            per_source.append((_LABELS.get(src, src), servers))
    return merge_server_lists(per_source), failed
